
<?php $email=$_REQUEST['Email'];
?>
 <form method="POST" action="UserRegAddAction.php">
             <div class="form-group">
                            <label for="email" class="">E-Mail Address</label>

                            <div class="">
                                <input id="email" type="email" class="form-control" placeholder="Enter your email" name="email" value="<?php echo $email; ?>" required>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                            </div>
             </div>
             
             <div class="form-group">
                            <label for="name" class="">Subject</label>

                            <div class="">
                                <input id="name" type="text" class="form-control" placeholder="Enter your name" name="name" value="" required autofocus>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
              </div>
             
             <div class="form-group">
                            <label for="name" class="">Message</label>

                            <div class="">
                                <textarea id="name" class="form-control" placeholder="Enter your name" name="name" rows="7" cols="5" required autofocus></textarea>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>

                       

                        <div class="form-group">
                            
                                <button type="submit" class="btn btn-primary">
                                    Submit
                                </button>
                            
                        </div>
 </form>   