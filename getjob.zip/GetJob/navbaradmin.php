<?php  

session_start();
?>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"></a>
    </div>
    <ul class="nav navbar-nav">
        
        <li><a href="HrUserList.php">User List</a></li>
        <li><a href="HrUserApply.php">Apply List</a></li>
        <li><a href="ContactUsAdminShow.php">Messages</a></li>
        <li><a href="FeedbackAdminShow.php">Feedback</a></li>
      
    </ul>
       <ul class="nav navbar-nav navbar-right">
   
      
      
     
      <li> <a class="dropdown-toggle" data-toggle="dropdown" href=""> <?Php echo $_SESSION["Name"]; ?>
      
          <span class="caret"></span>
           <ul class="dropdown-menu">
          <li><a href="Home.php">Logout</a></li>
         
  </div>
</nav>




