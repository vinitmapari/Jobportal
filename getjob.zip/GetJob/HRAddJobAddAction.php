
<?php  
$host = 'localhost';  
$user = 'vinit';  
$pass = 'vinit';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  


$Name=$_POST['name'];
$GradEdu = $_POST['GradEdu'];
$PostGradEdu = $_POST['PostGradEdu'];
$PrgLang = $_POST['PrgLang'];
$Venue = $_POST['Venue'];
$Package = $_POST['package'];
$Date = $_POST['date'];
$Time = $_POST['time'];


$sql = "INSERT INTO jobpost (Name,GradEdu,PostGradEdu,PrgLang,Venue,Package,Date,Time)
        VALUES ('$Name','$GradEdu','$PostGradEdu','$PrgLang','$Venue','$Package','$Date','$Time')"; 
if(mysqli_query($conn, $sql)){  
   header('Location: HRAddJob.php'); 
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  
  
mysqli_close($conn);  
?>  


