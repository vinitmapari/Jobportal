<?php
// Start the session
session_start();
?>
<?php

echo $_SESSION["Email"];




/*if(mysqli_num_rows($UserInfo) > 0){  
 while($row = mysqli_fetch_assoc($UserInfo)){  
    echo "First Name :{$row['FirstName']}  <br> ".  
         "Lasr NAME : {$row['LastName']} <br> ".  
         "Mnumber : {$row['Mnumber']} <br> ".  
                         "UserExp : {$row['UserExp']} <br> ".  
         "--------------------------------<br>";  
 } 
}else{  
echo "0 results";  
} */ 
$data=$_SESSION["User"];
print_r($data);


?>
