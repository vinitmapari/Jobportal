<?php
// Start the session
//session_start();
?>

<?php include 'header.php';?>
<?php include 'navbaradmin.php';?>
<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

//$EmailId=$_SESSION["Email"];
$EmailId=$_REQUEST['Email'];

  $sql = "select * from userwork where Email='$EmailId'"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $Companyname1=$row['Companyname1'];
    $CompanyAddress1=$row['CompanyAddress1'];
    $Experience1=$row['Experience1'];
    $JobLocation1=$row['JobLocation1'];
    $Designation1=$row['Designation1'];
    
    $Companyname2=$row['Companyname2'];
    $CompanyAddress2=$row['CompanyAddress2'];
    $Experience2=$row['Experience2'];
    $JobLocation2=$row['JobLocation2'];
    $Designation2=$row['Designation2'];
    
    $Companyname3=$row['Companyname3'];
    $CompanyAddress3=$row['CompanyAddress3'];
    $Experience3=$row['Experience3'];
    $JobLocation3=$row['JobLocation3'];
    $Designation3=$row['Designation3'];
    
    $Companyname4=$row['Companyname4'];
    $CompanyAddress4=$row['CompanyAddress4'];
    $Experience4=$row['Experience4'];
    $JobLocation4=$row['JobLocation4'];
    $Designation4=$row['Designation4'];
      
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 

?>
<form method="POST" action="HRUserSkillsProfile.php?Email=<?Php echo $EmailId; ?>">
<u><center><font size="20" color="RED" > WORK Expirence</font></center></u>
	<table border="1" width="100%" cellpadding="5" >

	<tr>
			<th></th>
			<th>Company Name</th>
			<th>Company Area Name</th>
			<th>Expirence</th>
			<th>Job Location</th>
			<th>Designation</th>
                        
	</tr>

		<tr>
			<td>1</td>
                      
			<td><?Php echo $Companyname1; ?></td>
			<td><?Php echo $CompanyAddress1; ?></td>
                        <td><?Php echo $Experience1; ?></td>
			
			<td>
                            <?Php echo $JobLocation1;  ?>
                        </td>
			
			<td>
                           <?Php echo $Designation1; ?>
                        </td>
			
                        
		</tr>
                
                <tr>
			<td>2</td>
                      
			<td><?Php echo $Companyname2; ?></td>
			<td><?Php echo $CompanyAddress2; ?></td>
                        <td><?Php echo $Experience2; ?></td>
			
			<td>
                            <?Php echo $JobLocation2;  ?>
                        </td>
			
			<td>
                           <?Php echo $Designation2; ?>
                        </td>
			
                        
		</tr>
                
                <tr>
			<td>1</td>
                      
			<td><?Php echo $Companyname3; ?></td>
			<td><?Php echo $CompanyAddress3; ?></td>
                        <td><?Php echo $Experience3; ?></td>
			
			<td>
                            <?Php echo $JobLocation3;  ?>
                        </td>
			
			<td>
                           <?Php echo $Designation3; ?>
                        </td>
			
                        
		</tr>
                
                <tr>
			<td>4</td>
                      
			<td><?Php echo $Companyname4; ?></td>
			<td><?Php echo $CompanyAddress4; ?></td>
                        <td><?Php echo $Experience4; ?></td>
			
			<td>
                            <?Php echo $JobLocation4;  ?>
                        </td>
			
			<td>
                           <?Php echo $Designation4; ?>
                        </td>
			
                        
		</tr>

		
                
        <tr>
		<td colspan="7" align="center"><br><br>
		  <input type="submit" class="btn btn-primary" value="Back">
                  
		</td>
	</tr>
		
        </table>				
	</form>
 <?php include 'footer.php';?>