<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php include 'header.php';?>
<?php include 'navbaradmin.php';?>

<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

$EmailId=$_REQUEST['Email'];
//echo $EmailId;
//$_SESSION["Email2"] = "$EmailId";
  $sql = "select * from useredu where EmailId='$EmailId'"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
   
$S_degree = $row['S_degree'];
$S_university = $row['S_university'];
$S_csname = $row['S_csname'];
$S_marks = $row['S_marks'];
$S_outof = $row['S_outof'];
$S_per = $row['S_per'];
$S_CGPA = $row['S_CGPA'];


$H_stream = $row['H_stream'];
$H_degree = $row['H_degree'];
$H_university = $row['H_university'];
$H_csname = $row['H_csname'];
$H_marks = $row['H_marks'];
$H_outof = $row['H_outof'];
$H_per = $row['H_per'];
$H_CGPA = $row['H_CGPA'];


$G_stream = $row['G_stream'];
$G_degree = $row['G_degree'];
$G_university = $row['G_university'];
$G_csname = $row['G_csname'];
$G_marks = $row['G_marks'];
$G_outof = $row['G_outof'];
$G_per = $row['G_per'];
$G_CGPA = $row['G_CGPA'];


$P_stream = $row['P_stream'];
$P_degree = $row['P_degree'];
$P_university = $row['P_university'];
$P_csname = $row['P_csname'];
$P_marks = $row['P_marks'];
$P_outof = $row['P_outof'];
$P_per = $row['P_per'];
$P_CGPA = $row['P_CGPA'];

$O_gdegree = $row['O_gdegree'];
$O_gper = $row['O_gper'];
$O_pgdegree = $row['O_pgdegree'];
$O_pgper = $row['O_pgper'];

$sscAchiv = $row['sscAchiv'];
$hscAchiv = $row['hscAchiv'];
$gradAchiv = $row['gradAchiv'];
$pgAchiv = $row['pgAchiv'];

    
    
    
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 

?>
<form  method="post" align="center" name="frmRegistration" action="HRUserSkillsProfile.php?Email=<?Php echo $EmailId; ?>" >
        
    <u><center><font size="20" color="RED" >Educational details</font></center></u>
	<table border="1" width="100%" cellpadding="5" >
        
        <tr>
	<th colspan="10"><font size="5" color="black">please fill the following</font></th>
	</tr>

		<tr>
			<th></th>
			<th>Stream</th>
			<th>Degree</th>
			<th>University</th>
			<th>College/school name</th>
			<th>Marks</th>
			<th>Out of</th>
			<th>Percentage</th>
			<th>C.G.P.A</th>
                        
		</tr>

		<tr>
			<td>SSC</td>
                        <td>
                          
                        </td>
                        <td>
                            
									
			 <?php echo $S_degree;?>					
		    				
                        </td>
			<td> <?php echo $S_university;?></td>
			<td> <?php echo $S_csname;?></td>
                        <td> <?php echo $S_marks;?></td>
			<td> <?php echo $S_outof;?></td>
			<td> <?php echo $S_per;?>%</td>
			<td> <?php echo $S_CGPA;?></td>
                        
		</tr>

		<tr>
			<td>HSC</td>
                        <td>
                            <?php echo $H_stream;?> 
                        </td>
                        <td>
                            <?php echo $H_degree;?> 
                        </td>
			<td> <?php echo $H_university;?></td>
			<td> <?php echo $H_csname;?></td>
                        <td> <?php echo $H_marks;?></td>
			<td> <?php echo $H_outof;?></td>
			<td> <?php echo $H_per;?>%</td>
			<td> <?php echo $H_CGPA;?></td>
                        
		</tr>
		
		<tr>
			<td>Graduate</td>
                        <td>
                            <?php echo $G_stream;?> 
                        </td>
                        <td>
                            <?php echo $G_degree;?> 
                        </td>
			<td> <?php echo $G_university;?></td>
			<td> <?php echo $G_csname;?></td>
                        <td> <?php echo $G_marks;?></td>
			<td> <?php echo $G_outof;?></td>
			<td> <?php echo $G_per;?>%</td>
			<td> <?php echo $G_CGPA;?></td>
                </tr>
		
		<tr>
			<td>Post Graduate</td>
                        <td>
                             <?php echo $P_stream;?>
                        </td>
                        <td>
                             <?php echo $P_degree;?>
                        </td>
                        <td> <?php echo $P_university;?></td>
			<td> <?php echo $P_csname;?></td>
                        <td> <?php echo $P_marks;?></td>
			<td> <?php echo $P_outof;?></td>
			<td> <?php echo $P_per;?>%</td>
			<td> <?php echo $P_CGPA;?></td>
                        
		</tr>
		
        </table>				
	
    <table border="1">
        
        <tr>  
            <th colspan="2"><font size="5" color="RED" ><u>Other degree if any</u></font></th> 
        </tr>
        
        
        
	<tr>
		
		<td><font color="black">Graduate level Degree</td>
		<td><font color="black"> <?php echo $O_gdegree;?></td>
	</tr>
        <tr>
		
		<td><font color="black">Graduate Percentage</td>
		<td><font color="black"> <?php echo $O_gper;?></td>
	</tr>
        
	<tr>
		
		<td><font color="black">Post Graduate level</td>
		<td><font color="black"> <?php echo $O_pgdegree;?></td>
	</tr>
        <tr> 
		
		<td><font color="black">Post Graduate Percentage</td>
		<td><font color="black"> <?php echo $O_pgper;?></td>
	</tr>
        
    </table>
        
    <table border="1">
        <tr>
            <th colspan="2"><font size="5" color="RED" ><u>Educational level achievements</u></font></th>
        </tr>
        
	<tr>
		
		<td><font color="black"> SSC level achievements </td>
                <td><font color="black"> <?php echo $sscAchiv;?></td>
	</tr>
	<tr>
		
		<td><font color="black">HSC level achievements</td>
		<td><font color="black"> <?php echo $hscAchiv;?></td>
	</tr>


	<tr>
                
		<td><font color="black"> Graduate level achievements</td>
		<td><font color="black"> <?php echo $gradAchiv;?></td>
	</tr>
	<tr>
		
		<td><font color="black"> Post Graduate level achievements</td>
		<td><font color="black"> <?php echo $pgAchiv;?></td>
	</tr>
	

        <tr>
		<td colspan="2" align="center"><br><br>
		  <input type="submit" class="btn btn-primary" value="Next">
                  <a href="HRUserBasicProfile.php?Email=<?php echo $EmailId; ?>">Back</a>
		</td>
	</tr>

	</table>

    </form>
<?php include 'footer.php';?>	


