<?php
session_start();
?>
<?php include 'header.php';?>
<?php include 'navbaruser.php';?>

<?php      


$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  

$Email=$_SESSION['Email'];
//echo $_SESSION['Email'];
$Name=$_SESSION['Name1'];
//echo $_SESSION['Name'];
$PrgLang=$_SESSION['PrgLang'];
$Venue=$_SESSION['Venue'];
$Date=$_SESSION['Date'];       
$Time=$_SESSION['Time'];    
$Package=$_SESSION['Package'];
$id=$_SESSION['Id'];

$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
$sql="Insert Into userapply (email,Name,prglang,Date,venue,time,Package)
        values('$Email','$Name','$PrgLang','$Date','$Venue','$Time','$Package');";
if(mysqli_query($conn, $sql)){  
   ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><?Php  ?>  </div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="UserRegAddAction.php">
                       

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Job Post</label>

                            <div class="col-md-6">
                                
                                <label for="name" class="col-md-4 control-label"><?Php echo $Name; ?></label>
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">Programming Langauages</label>

                            <div class="col-md-6">
                                
                                 <label for="name" class="col-md-4 control-label"><?Php echo $PrgLang; ?></label>
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password" class="col-md-4 control-label">Package</label>

                            <div class="col-md-6">
                             <label for="name" class="col-md-4 control-label"><?Php echo $Package; ?></label>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Date</label>

                            <div class="col-md-6">
                             <label for="name" class="col-md-4 control-label"><?Php echo $Date; ?></label>
                           <span class="help-block">
                                        <strong><span id='message'></span></strong>
                                    </span>
                               
                            </div>
                        </div>
                        
                         <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Time</label>

                            <div class="col-md-6">
                             <label for="name" class="col-md-4 control-label"><?Php echo $Time; ?></label>
                           <span class="help-block">
                                        <strong><span id='message'></span></strong>
                                    </span>
                               
                            </div>
                        </div>
                        
                         <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Venue</label>

                            <div class="col-md-6">
                             <label for="name" class="col-md-4 control-label"><?Php echo $Venue; ?></label>
                           <span class="help-block">
                                        <strong><span id='message'></span></strong>
                                    </span>
                               
                            </div>
                        </div>
                        <div class="alert alert-success">
                            <strong>Successfully submitted!</strong> 
                        </div>
                        
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary" onclick="window.print()">
                                    Print
                                </button>
                                <a href="UserJobShow.php?id=<?php echo $id; ?>">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br>

<?Php
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  

mysqli_close($conn);  
?>  
<?php include 'footer.php';?>
