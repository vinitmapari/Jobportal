<?php  

session_start();
$Email=$_SESSION["Email"];

$host = 'localhost';  
$user = 'vinit';  
$pass = 'vinit';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  




$PerAdd = $_POST['PerAdd'];
$PerPin = $_POST['PerPin'];
$Age = $_POST['Age'];
$Gender = $_POST['Gender'];
$Country = $_POST['Country'];
$State = $_POST['State'];
$City = $_POST['City'];
$AltEmail = $_POST['AltEmail'];
$AltMobileNo = $_POST['AltMobileNo'];


$sql = "Update userreg set PerAdd='$PerAdd',PerPin='$PerPin',Age='$Age',Gender='$Gender',Country='$Country',State='$State',City='$City',AltEmail='$AltEmail',MobNo='$AltMobileNo' where Email='$Email';"; 
if(mysqli_query($conn, $sql)){  
 echo "Record inserted successfully";
 header('Location: UserFormBasicProfile.php'); 
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  
  
mysqli_close($conn);  
?>  


