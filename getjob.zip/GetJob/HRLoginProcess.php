<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
// Start the session
session_start();
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  


$EmailId=$_POST['email'];
$Passwd=$_POST['password'];
echo $EmailId;
echo $Passwd;

  $sql = "select * from hrreg where Email='$EmailId'  and Password='$Passwd'"; 
  
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    $_SESSION["Email"] = "$EmailId";
    var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   $numrows=mysqli_num_rows($result);
   echo $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $name=$row['Name'];
    $Email=$row['Email'];
    $_SESSION["Name"] = "$name";
    
    
 
    
}


   
    header('Location: HRProfile.php'); 
    
   
}
else
{  
    echo '0';
}  
  
 

?>
    </body>
</html>
