<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
// Start the session
session_start();
?>

<?php include 'header.php';?>
<?php include 'navbaruser.php';?>


    <form  method="post" align="center" name="frmRegistration" action="UserFormEduAddAction.php" >
        
    <u><center><font size="20" color="RED" >Educational details</font></center></u>
	<table border="1" width="100%" cellpadding="5" >
        
        <tr>
	<th colspan="10"><font size="5" color="black">please fill the following</font></th>
	</tr>

		<tr>
			<th></th>
			<th>Stream</th>
			<th>Degree</th>
			<th>University</th>
			<th>College/school name</th>
			<th>Marks</th>
			<th>Out of</th>
			<th>Percentage</th>
			<th>C.G.P.A</th>
                        
		</tr>

		<tr>
			<td>SSC</td>
                        <td>
                            
                        </td>
                        <td>
                             <select name="degreessc" required="required">
									<option value="SSC">SSC</option>
									
								
		    						</select>
                        </td>
			<td><input type="text" name="UniversitySSC" required="required"></td>
			<td><input type="text" name="ClgSchNameSSC" required="required"></td>
                        <td><input type="number" name="MarksSSC" required="required" maxlength="4" size="4"></td>
			<td><input type="number" name="OutOfSSC" required="required" maxlength="4" size="4"></td>
			<td><input type="number" name="PercentageSSC" required="required" maxlength="5" size="5">%</td>
			<td><input type="number" name="CGPASSC" required="required" maxlength="5" size="5"></td>
                        
		</tr>

		<tr>
			<td>HSC</td>
                        <td>
                            <select name="streamhsc" required="required">
									<option value="Science"> Science </option>
									<option value="Commerce"> Commerce </option>
                                                                        <option value="Arts"> Arts </option>
                            </select>
                        </td>
                        <td>
                            <select name="degreehsc" required="required">
									<option value="HSC"> HSC</option>
								
								
		    						</select>
                        </td>
			<td><input type="text" name="UniversityHSC" required="required"></td>
			<td><input type="text" name="ClgSchNameHSC" required="required"></td>
                        <td><input type="number" name="MarksHSC" required="required" maxlength="4" size="4"></td>
			<td><input type="number" name="OutOfHSC" required="required" maxlength="4" size="4"></td>
			<td><input type="number" name="PercentageHSC" required="required" maxlength="5" size="5">%</td>
			<td><input type="number" name="CGPAHSC" required="required" maxlength="5" size="5"></td>
                        
		</tr>
		
		<tr>
			<td>Graduate</td>
                        <td>
                            <select name="streamgrad" required="required">
									<option value="Science"> Science </option>
									<option value="Commerce"> Commerce </option>
                                                                        <option value="Arts"> Arts </option>
                            
								
		    						</select>
                        </td>
                        <td>
                            <select name="degreegrad" required="required">
									<option value="BSC"> BSC </option>
									<option value="BCOM"> BCOM </option>
                                                                        <option value="BSC(CS)"> BSC(CS) </option>
									<option value="BSC(IT)"> BSC(IT)</option>
                                                                        <option value="BCA"> BCA </option>
                                                                        <option value="BAF">BAF</option>
                                                                        <option value="BMM"> BMM </option>
									<option value="BA">BA</option>
                                                                        <option value="BE">BE</option>
                                                                        
								
		    						</select>
                        </td>
			<td><input type="text" name="UniversityGrad" required="required"></td>
			<td><input type="text" name="ClgSchNameGrad" required="required"></td>
                        <td><input type="number" name="MarksGrad" required="required" maxlength="4" size="4"></td>
			<td><input type="number" name="OutOfGrad" required="required" maxlength="4" size="4"></td>
			<td><input type="number" name="PercentageGrad" required="required" maxlength="5" size="5">%</td>
			<td><input type="number" name="CGPAGrad" required="required" maxlength="5" size="5"></td>
                        		</tr>
		
		<tr>
			<td>Post Graduate</td>
                        <td>
                            <select name="streampg" required="required">
									<option value="Science"> Science </option>
									<option value="Commerce"> Commerce </option>
                                                                        <option value="Arts"> Arts </option>
                            	</select>
                        </td>
                        <td>
                            <select name="degreepg" required="required">
									<option value="MSC"> MSC </option>
									<option value="MCOM"> MCOM </option>
                                                                        <option value="MSC(CS)"> MSC(CS) </option>
									<option value="MSC(IT)"> MSC(IT)</option>
                                                                        <option value="MCA"> MCA </option>
                                                                        <option value="MBA">MBA</option>
                                                                        <option value="MTECH">MTech </option>
									<option value="ME">ME</option>
		    						</select>
                        </td>
                        <td><input type="text" name="UniversityPG" required="required"></td>
			<td><input type="text" name="ClgSchNamePG" required="required"></td>
                        <td><input type="number" name="MarksPG" required="required" maxlength="4" size="4"></td>
			<td><input type="number" name="OutOfPG" required="required" maxlength="4" size="4"></td>
			<td><input type="number" name="PercentagePG" required="required" maxlength="5" size="5">%</td>
			<td><input type="number" name="CGPAPG" required="required" maxlength="5" size="5"></td>
                        
		</tr>
		
        </table>				
	
    <table border="1">
        
        <tr>  
            <th colspan="2"><font size="5" color="RED" ><u>Other degree if any</u></font></th> 
        </tr>
        
        
        
	<tr>
		
		<td><font color="black">Graduate level Degree</td>
		<td><font color="black"><input type="text" name="AGDName" required="required"></td>
	</tr>
        <tr>
		
		<td><font color="black">Graduate Percentage</td>
		<td><font color="black"><input type="number" name="AGDPer" required="required"></td>
	</tr>
        
	<tr>
		
		<td><font color="black">Post Graduate level</td>
		<td><font color="black"><input type="text" name="APGDName" required="required"></textarea></td>
	</tr>
        <tr> 
		
		<td><font color="black">Post Graduate Percentage</td>
		<td><font color="black"><input type="number" name="APGDPer" required="required"></td>
	</tr>
        
    </table>
        
    <table border="1">
        <tr>
            <th colspan="2"><font size="5" color="RED" ><u>Educational level achievements</u></font></th>
        </tr>
        
	<tr>
		
		<td><font color="black"> SSC level achievements </td>
                <td><font color="black"><textarea name="SSCAchiv" rows="3" cols="16"  required="required"></textarea></td>
	</tr>
	<tr>
		
		<td><font color="black">HSC level achievements</td>
		<td><font color="black"><textarea name="HSCAChiv" rows="3" cols="16"  required="required"></textarea></td>
	</tr>


	<tr>
                
		<td><font color="black"> Graduate level achievements</td>
		<td><font color="black"><textarea name="GradAchiv" rows="3" cols="16"  required="required"></textarea></td>
	</tr>
	<tr>
		
		<td><font color="black"> Post Graduate level achievements</td>
		<td><font color="black"><textarea name="PGradAchiv" rows="3" cols="16"  required="required"></textarea></td>
	</tr>
	

        <tr>
		<td colspan="2" align="center"><br><br>
		  <font color="black"><input type="submit" value="Submit">
		</td>
	</tr>

	</table>

    </form>
<?php include 'footer.php';?>	


