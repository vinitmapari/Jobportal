<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php include 'header.php';?>
<?php include 'navbaradmin.php';?>

<br><br>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Job Posting</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="HRAddJobAddAction.php">
                       

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Job Post</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control" placeholder="Enter your post" name="name" value="" required autofocus>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">Education Requirement Graduation</label>

                            <div class="col-md-6">
                                <select name="GradEdu">
                                    <option value="">select your education</option>
                                    <option value="BSC">BSC</option>
                                    <option value="BCA">BCA</option>
                                </select>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">Education Requirement Post Graduation</label>

                            <div class="col-md-6">
                                <select name="PostGradEdu">
                                    <option value="">select your education</option>
                                    <option value="MSC">MSC</option>
                                    <option value="MCA">MCA</option>
                                </select>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">Pragramming Language Known</label>

                            <div class="col-md-6">
                                <select name="PrgLang">
                                    <option value="">select your programming Langauge</option>
                                    <option value="Java">Java</option>
                                    <option value="Php">Php</option>
                                </select>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                            </div>
                        </div>

                        

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Venue</label>

                            <div class="col-md-6">
                                <textarea  class="form-control"  name="Venue"  required>
                                    
                                </textarea>
                           <span class="help-block">
                                        <strong><span id='message'></span></strong>
                                    </span>
                               
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Package</label>

                            <div class="col-md-6">
                                <input id="name" type="number" class="form-control" placeholder="Enter your package" name="package" value="" required autofocus>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Date of Interview</label>

                            <div class="col-md-6">
                                <input  type="date" class="form-control" placeholder="Enter your time" name="date" value="" required autofocus>
                               
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Time</label>

                            <div class="col-md-6">
                                <input  type="time" class="form-control" placeholder="Enter your time" name="time" value="" required autofocus>
                               
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    POST
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br>
<?php include 'footer.php';?>