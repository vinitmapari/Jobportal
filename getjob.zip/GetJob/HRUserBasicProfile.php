<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->

<?php include 'header.php';?>
<?php include 'navbaradmin.php';?>
<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

$EmailId=$_REQUEST['Email'];
////echo $EmailId;
 //$_SESSION["Email1"] = "$EmailId";
  $sql = "select * from userreg where Email='$EmailId'"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
   
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $name=$row['Name'];
    $Email=$row['Email'];
    $MobNo=$row['MobNo'];
    $Age=$row['Age'];
    $Gender=$row['Gender'];
    $PerAdd=$row['PerAdd'];
    $PerPin=$row['PerPin'];
    $State=$row['State'];
    $City=$row['City'];
    $AltEmail=$row['AltEmail'];
    $Country=$row['Country'];
      
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 

?>
<form  method="post" align="center" name="frmRegistration" action="HRUserEduProfile.php?Email=<?Php echo $Email; ?>" >
        
    <u><center><font size="20" color="RED" >User Basic Profile</font></center></u>
	<table border="0" width="100%" cellpadding="5" >
        
	
        <tr>
            <td>Name</td>
            <td><?Php echo $name; ?></td>
        </tr>
        
         <tr>
            <td>Email</td>
            <td><?Php echo $Email; ?></td>
        </tr>
        
         <tr>
            <td>Mobile No</td>
            <td><?Php echo $MobNo; ?></td>
        </tr>
        
	<tr>
		
		<td><font color="black"> Permanent Address2</td>
		<td><font color="black"><?Php echo $PerAdd; ?></td>
	</tr>
        <tr>
		
		<td><font color="black">Permanent Pin code </td>
		<td><font color="black"><?Php echo $PerPin; ?></td>
	</tr>
	<tr>
		
		<td><font color="black"> Age </td>
                <td><font color="black"><?Php echo $Age; ?></td>
	</tr>
	<tr>
		
		<td><font color="black"> Gender </td>
		<td><font color="black"><?Php echo $Gender; ?></td>
	</tr>


	<tr>
                
		<td><font color="black"> Country </td>
		<td><font color="black"><?Php echo $Country; ?></td>
	</tr>
	<tr>
		
		<td><font color="black"> State</td>
		<td><font color="black"><?Php echo $State; ?></td>
	</tr>
	
	<tr>
		
		<td><font color="black"> City </td>
		<td><font color="black"><?Php echo $City; ?></td>
	</tr>

	<tr>
		
		<td><font color="black"> Alternative Email ID</td>
		<td><font color="black"><?Php echo $AltEmail; ?></td>
	</tr>
        
        <tr>
		<td colspan="3" align="center"><br><br>
		  <input type="submit" value="Next" class="btn btn-primary">
                  <a href="UserBasicUpdate.php">Update</a>
		</td>
	</tr>

	</table>

    </form>
 <?php include 'footer.php';?>
    