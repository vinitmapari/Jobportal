<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
// Start the session
session_start();
?>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  


$EmailId=$_POST['email'];
$Passwd=$_POST['password'];
echo $EmailId;
echo $Passwd;

  $sql = "select * from userreg where Email='$EmailId'  and Passwd='$Passwd'"; 
  //var_dump($sql); 
//if(mysqli_query($conn, $sql))
//{  
   
    $result = mysqli_query($conn,$sql);
    $_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //echo $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $name=$row['Name'];
    $Email=$row['Email'];
    $PerAdd=$row['PerAdd'];
    $_SESSION["Name"] = "$name";
    
    
 
    
}

    
   
//}
//else
//{  
  //  echo '0';
//}  
 
 $sql = "select * from userwork where Email='$EmailId'"; 
  //var_dump($sql); 
//if(mysqli_query($conn, $sql))
//{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //echo $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $companyname=$row['Companyname1'];
    echo $companyname;
}

$sql = "select * from userskills where Email='$EmailId'"; 
  //var_dump($sql); 
//if(mysqli_query($conn, $sql))
//{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //echo $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $LangInterest=$row['LangInt'];
    //$Email=$row['Email'];
    //$_SESSION["Name"] = "$name";
    echo $LangInterest;
    
 
    
}
$sql = "select * from useredu where EmailId='$EmailId'"; 
  //var_dump($sql); 
//if(mysqli_query($conn, $sql))
//{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //echo $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $csname=$row['S_csname'];
    //$Email=$row['Email'];
    //$_SESSION["Name"] = "$name";
    echo $csname;
    
 
    
}
echo $PerAdd;
?>
        <?Php
   if($PerAdd=='')
   {
    header('Location: UserFormBasic.php'); 
   }
   elseif($csname==''){
       header('Location: UserFormEdu.php'); 
   }
    elseif($LangInterest==''){
       header('Location: UserFormSkills.php'); 
   }  
 elseif($companyname==''){
       header('Location: UserFormWork.php'); 
   }
   
   else
   {
      header('Location: UserFormBasicProfile.php');  
   }
     ?>
    </body>
</html>
