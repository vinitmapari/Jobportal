
 <table border="0" width="100%" cellpadding="5" class="table">
        
     <thead>
		<tr>
			
			<th>Name</th>
			<th>Email </th>
			<th>Graduation</th>
                        <th>Post Graduation</th>
			<th>Programming Langauges</th>
			<th>Interested Language</th>
			
                        
		</tr>
     </thead>
<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

//$email=$_REQUEST['Email'];
//$email1=$_REQUEST['Email1'];
  //$sql = "SELECT userreg.Name,useredu.G_degree,useredu.P_degree, userreg.Email
//FROM userreg
//INNER JOIN useredu ON userreg.Email=useredu.EmailId;"; 
  //var_dump($sql); 

if($_REQUEST['Email']!="" && $_REQUEST['Email1']=="")
{
    $email=$_REQUEST['Email'];
 $sql="SELECT userreg.Name,useredu.G_degree,useredu.P_degree, userreg.Email,userskills.prglang,
 userskills.LangInt FROM ((userreg
INNER JOIN useredu ON userreg.Email=useredu.EmailId)
INNER JOIN userskills ON userreg.Email = userskills.email)where userskills.LangInt='$email';";
 $result = mysqli_query($conn,$sql);
 while($row = mysqli_fetch_assoc($result)) {
       
    
    $Name=$row['Name'];
    $Email=$row['Email'];
    $S_degree=$row['G_degree'];
    $H_degree=$row['P_degree'];
    $prglang=$row['prglang'];
    $LangInt=$row['LangInt'];
    
    //$sql = "INSERT INTO userlist (Name,Email,Graduation,Pgraduation,Skills,IntLang) VALUES ('$Name','$Email','$S_degree','$H_degree','$prglang','$LangInt')"; 
     //mysqli_query($conn, $sql);
    
    
    ?>
                
                <tr>
			
			<td><?Php echo $Name;?></td>
			<td><?Php echo $Email;?></td>
			<td><?Php echo $S_degree;?></td>
			<td><?Php echo $H_degree;?></td>
			<td><?Php echo $prglang;?></td>
                        <td><?Php echo $LangInt;?></td>
                        
    </tr>
              
                
                
                <?Php
    }

    
    
    ?>
       
                
 <?Php                
  
//}

?>
        </table>
 <?php
}
 elseif ($_REQUEST['Email']=="" && $_REQUEST['Email1']!="") {
     $email1=$_REQUEST['Email1'];
    $sql="SELECT userreg.Name,useredu.G_degree,useredu.P_degree, userreg.Email,userskills.prglang,
 userskills.LangInt FROM ((userreg
INNER JOIN useredu ON userreg.Email=useredu.EmailId)
INNER JOIN userskills ON userreg.Email = userskills.email)where useredu.P_degree='$email1';";
    $result = mysqli_query($conn,$sql);
    while($row = mysqli_fetch_assoc($result)) {
       
    
    $Name=$row['Name'];
    $Email=$row['Email'];
    $S_degree=$row['G_degree'];
    $H_degree=$row['P_degree'];
    $prglang=$row['prglang'];
    $LangInt=$row['LangInt'];
    
    //$sql = "INSERT INTO userlist (Name,Email,Graduation,Pgraduation,Skills,IntLang) VALUES ('$Name','$Email','$S_degree','$H_degree','$prglang','$LangInt')"; 
     //mysqli_query($conn, $sql);
    
    
    ?>
                
                <tr>
			
			<td><?Php echo $Name;?></td>
			<td><?Php echo $Email;?></td>
			<td><?Php echo $S_degree;?></td>
			<td><?Php echo $H_degree;?></td>
			<td><?Php echo $prglang;?></td>
                        <td><?Php echo $LangInt;?></td>
                        
    </tr>
              
                
                
                <?Php
    }

    
    
    ?>
       
                
 <?Php                
  
//}

?>
        </table>
        <?php
}
elseif ($_REQUEST['Email']!="" && $_REQUEST['Email']!="") {
    $email=$_REQUEST['Email'];
    $email1=$_REQUEST['Email1'];
    $sql="SELECT userreg.Name,useredu.G_degree,useredu.P_degree, userreg.Email,userskills.prglang,
 userskills.LangInt FROM ((userreg
INNER JOIN useredu ON userreg.Email=useredu.EmailId)
INNER JOIN userskills ON userreg.Email = userskills.email)where userskills.LangInt='$email' AND useredu.P_degree='$email1';";
$result = mysqli_query($conn,$sql);
while($row = mysqli_fetch_assoc($result)) {
       
    
    $Name=$row['Name'];
    $Email=$row['Email'];
    $S_degree=$row['G_degree'];
    $H_degree=$row['P_degree'];
    $prglang=$row['prglang'];
    $LangInt=$row['LangInt'];
    
    //$sql = "INSERT INTO userlist (Name,Email,Graduation,Pgraduation,Skills,IntLang) VALUES ('$Name','$Email','$S_degree','$H_degree','$prglang','$LangInt')"; 
     //mysqli_query($conn, $sql);
    
    
    ?>
                
                <tr>
			
			<td><?Php echo $Name;?></td>
			<td><?Php echo $Email;?></td>
			<td><?Php echo $S_degree;?></td>
			<td><?Php echo $H_degree;?></td>
			<td><?Php echo $prglang;?></td>
                        <td><?Php echo $LangInt;?></td>
                        
    </tr>
              
                
                
                <?Php
    }

    
    
    ?>
       
                
 <?Php                
  
//}

?>
        </table>
        <?php
}

    //$result = mysqli_query($conn,$sql);
    
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   //while ($row1 = mysqli_fetch_assoc($result1) && $row2 = mysqli_fetch_assoc($result2) 
           //&& $row3 = mysqli_fetch_assoc($result3) && $row4 = mysqli_fetch_assoc($result4)) 
//{
    
    // output data of each row
  ?>  