
<?php  

session_start();
$Email=$_SESSION["Email"];

$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  


$S_degree = $_POST['degreessc'];
$S_university = $_POST['UniversitySSC'];
$S_csname = $_POST['ClgSchNameSSC'];
$S_marks = $_POST['MarksSSC'];
$S_outof = $_POST['OutOfSSC'];
$S_per = $_POST['PercentageSSC'];
$S_CGPA = $_POST['CGPASSC'];


$H_stream = $_POST['streamhsc'];
$H_degree = $_POST['degreehsc'];
$H_university = $_POST['UniversityHSC'];
$H_csname = $_POST['ClgSchNameHSC'];
$H_marks = $_POST['MarksHSC'];
$H_outof = $_POST['OutOfHSC'];
$H_per = $_POST['PercentageHSC'];
$H_CGPA = $_POST['CGPAHSC'];


$G_stream = $_POST['streamgrad'];
$G_degree = $_POST['degreegrad'];
$G_university = $_POST['UniversityGrad'];
$G_csname = $_POST['ClgSchNameGrad'];
$G_marks = $_POST['MarksGrad'];
$G_outof = $_POST['OutOfGrad'];
$G_per = $_POST['PercentageGrad'];
$G_CGPA = $_POST['CGPAGrad'];


$P_stream = $_POST['streampg'];
$P_degree = $_POST['degreepg'];
$P_university = $_POST['UniversityPG'];
$P_csname = $_POST['ClgSchNamePG'];
$P_marks = $_POST['MarksPG'];
$P_outof = $_POST['OutOfPG'];
$P_per = $_POST['PercentagePG'];
$P_CGPA = $_POST['CGPAPG'];

$O_gdegree = $_POST['AGDName'];
$O_gper = $_POST['AGDPer'];
$O_pgdegree = $_POST['APGDName'];
$O_pgper = $_POST['APGDPer'];

$sscAchiv = $_POST['SSCAchiv'];
$hscAchiv = $_POST['HSCAChiv'];
$gradAchiv = $_POST['GradAchiv'];
$pgAchiv = $_POST['PGradAchiv'];






$sql = "INSERT INTO useredu (EmailId,S_degree,S_university,S_csname,S_marks,S_outof,S_per,S_CGPA,
                             H_stream,H_degree,H_university,H_csname,H_marks,H_outof,H_per,H_CGPA,
                             G_stream,G_degree,G_university,G_csname,G_marks,G_outof,G_per,G_CGPA,
                             P_stream,P_degree,P_university,P_csname,P_marks,P_outof,P_per,P_CGPA,
                                    O_gdegree,O_gper,O_pgdegree,O_pgper,
                                    sscAchiv,hscAchiv,gradAchiv,pgAchiv)
VALUES ('$Email','$S_degree','$S_university','$S_csname','$S_marks', '$S_outof','$S_per','$S_CGPA',
        '$H_stream', '$H_degree','$H_university', '$H_csname','$H_marks', '$H_outof','$H_per', '$H_CGPA',
        '$G_stream', '$G_degree','$G_university', '$G_csname','$G_marks', '$G_outof','$G_per', '$G_CGPA', 
        '$P_stream', '$P_degree','$P_university', '$P_csname','$P_marks', '$P_outof','$P_per', '$P_CGPA',
        '$O_gdegree', '$O_gper','$O_pgdegree', '$O_pgper','$sscAchiv', '$hscAchiv','$gradAchiv', '$pgAchiv');"; 
if(mysqli_query($conn, $sql)){  
 echo "Record inserted successfully";
 header('Location: UserFormSkills.php'); 
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  
  
mysqli_close($conn);  
?>  


