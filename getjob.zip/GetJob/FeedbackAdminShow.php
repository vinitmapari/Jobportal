<?php include 'header.php';?>
<?php include 'navbaradmin.php';?>
<div class="container">
<div class="col-md-8 col-lg-8">
    <center><h1>Feedback</h1></center>
<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

  $sql = "select * from feedback"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $name=$row['name'];
    $email=$row['email'];
    $feedback=$row['feedback'];
    
   ?>
        
        

    
<ul class="list-group">
    <li class="list-group-item">Name:<?Php echo $name; ?></li> 
    <li class="list-group-item">Email:<?Php echo $email; ?></li> 
    <li class="list-group-item">Message:<?Php echo $feedback; ?></li> 
</ul>
    

        <?Php
    
      
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 

?>
	</div>
<div class="col-md-4 col-lg-4">
    <h1></h1>
</div>
</div>
    <?php include 'footer.php';?>

