<?php include 'header.php';?>
<?php include 'navbar.php';?>
<form name='' action="ContactUsAddAction.php" method="POST">

<div class="container">
    <div class="col-md-8 col-lg-8">
        <div class="panel panel-default">
                <div class="panel-heading">Contact Us</div>

                <div class="panel-body">
<div class="form-group">
    <label name=''>Name</label>
    <input type="text" class='form-control' name="Name" placeholder='Enter name'>
    
</div>

<div class="form-group">
     <label name=''>Email</label>
     <input type="email" class='form-control' placeholder='Enter name' name="Email">
</div>

<div class="form-group">
     <label name=''>Message</label>
     <textarea class='form-control' rows="10" cols="16" placeholder='Enter name' name="Message"></textarea>
</div>
<div>
    <input type="submit" class="btn btn-primary">
</div>
    </div>
    <div class="col-md-4 col-lg-4">
        
    </div>
</div>
        </div>
    </div>
    
</form>
<br><br>

<?php include 'footer.php';?>