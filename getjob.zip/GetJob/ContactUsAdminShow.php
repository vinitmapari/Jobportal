<?php include 'header.php';?>
<?php include 'navbaradmin.php';?>
<div class="container">
<div class="col-md-8 col-lg-8">
     <font size="6"> <b>Messages</b></font>
       <div class="myBox1">
    
<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

  $sql = "select * from contactus"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $name=$row['name'];
    $email=$row['email'];
    $feedback=$row['message'];
    
   ?>
        
        

    
<ul class="list-group">
    <li class="list-group-item">Name:<?Php echo $name; ?></li> 
    <li class="list-group-item">Email:<?Php echo $email; ?></li> 
    <li class="list-group-item">Message:<?Php echo $feedback; ?></li> 
    <li class="list-group-item">
        <a onclick="showUser('<?php echo $email ?>');">Reply</a></li> 
</ul>
    

        <?Php
    
      
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 

?>
       </div>
</div>
     <div class="col-md-4 col-lg-4">
         <font size="6"> <b>Email</b></font>
          <font size="2"> <b>Please click on reply to email</b></font>
             <div class="panel panel-default">
                <div class="panel-heading">Email to Customer</div>

                <div class="panel-body">
        
        
             <div id="txtHint"></div>
             
                </div>
             </div>
     
    </div>
</div>

<script> 
function showUser(str) {
   alert(str);
        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint").innerHTML = this.responseText;
            }
        };
        xmlhttp.open("GET","MessageReply.php?Email="+str,true);
        xmlhttp.send();
    }
</script>
   <br> 
<?php include 'footer.php';?>

