<?php
// Start the session
session_start();
?>


<?php include 'header.php';?>
<?php include 'navbaruser.php';?>

<form method="POST" action="UserFormWorkAddAction.php">
<u><center><font size="20" color="RED" > WORK Expirence</font></center></u>
	<table border="1" width="100%" cellpadding="5" >
        
        <tr>
	<th colspan="10"><font size="5" color="black">please fill the following</font></th>
	</tr>

	<tr>
			<th></th>
			<th>Company Name</th>
			<th>Company Area Name</th>
			<th>Expirence</th>
			<th>Job Location</th>
			<th>Designation</th>
                        
	</tr>

		<tr>
			<td>1</td>
                      
			<td><input type="textarea" name="Companyname1" required="required"></td>
			<td><input type="textarea" name="CompanyAddress1" required="required"></td>
                        <td><input type="number" name="Experience1" required="required" maxlength="10" size="10"></td>
			
			<td>
                            <select name="JobLocation1" required="required">
									<option value="Mumbai"> Mumbai </option>
									<option value="Delhi"> Delhi</option>
                                    <option value="Kolkata"> Kolkata </option>
									 <option value="Pune"> Pune</option>
									  <option value="Bhopal"> Bhopal </option>
								
                            </select>
                        </td>
			
			<td>
                            <select name="Designation1" required="required">
									<option value="JavaDeveloper"> Java Developer </option>
									<option value="FrontEndDeveloper"> FrontEnd Developer </option>
                                    <option value="BackEndDeveloper"> BackEnd Developer </option>
									 <option value="PhythonDeveloper"> Phython Developer </option>
									  <option value="SoftwareDeveloper"> Software Developer </option>
								
                            </select>
                        </td>
			
                        
		</tr>

		<tr>
			<td>2</td>
                      
			<td><input type="textarea" name="Companyname2" required="required"></td>
			<td><input type="textarea" name="CompanyAddress2" required="required"></td>
                        <td><input type="number" name="Experience2" required="required" maxlength="4" size="4"></td>
			
			<td>
                            <select name="JobLocation2" required="required">
									<option value="Mumbai"> Mumbai </option>
									<option value="Delhi"> Delhi</option>
                                    <option value="Kolkata"> Kolkata </option>
									 <option value="Pune"> Pune</option>
									  <option value="Bhopal"> Bhopal </option>
								
                            </select>
            </td>
			<td>
                            <select name="Designation2" required="required">
									<option value="JavaDeveloper"> Java Developer </option>
									<option value="FrontEndDeveloper"> FrontEnd Developer </option>
                                    <option value="BackEndDeveloper"> BackEnd Developer </option>
									 <option value="PhythonDeveloper"> Phython Developer </option>
									  <option value="SoftwareDeveloper"> Software Developer </option>
								
                            </select>
            </td>
			
                       
		</tr>
		
		<tr>
			<td>3</td>
                        
			<td><input type="textarea" name="Companyname3" required="required"></td>
			<td><input type="textarea" name="CompanyAddress3" required="required"></td>
                        <td><input type="number" name="Experience3" required="required" maxlength="10" size="10"></td>
			
			<td>
                            <select name="JobLocation3" required="required">
									<option value="Mumbai"> Mumbai </option>
									<option value="Delhi"> Delhi</option>
                                    <option value="Kolkata"> Kolkata </option>
									 <option value="Pune"> Pune</option>
									  <option value="Bhopal"> Bhopal </option>
								
                            </select>
            </td>
			<td>
                            <select name="Designation3" required="required">
									<option value="JavaDeveloper"> Java Developer </option>
									<option value="FrontEndDeveloper"> FrontEnd Developer </option>
                                    <option value="BackEndDeveloper"> BackEnd Developer </option>
									 <option value="PhythonDeveloper"> Phython Developer </option>
									  <option value="SoftwareDeveloper"> Software Developer </option>
								
                            </select>
            </td>
                        		</tr>
		
		<tr>
			<td>4</td>
                       
            <td><input type="textarea" name="Companyname4" required="required"></td>
			<td><input type="textarea" name="CompanyAddress4" required="required"></td>
                        <td><input type="number" name="Experience4" required="required" maxlength="4" size="4"></td>
			
			<td>
                            <select name="JobLocation4" required="required">
									<option value="Mumbai"> Mumbai </option>
									<option value="Delhi"> Delhi</option>
                                    <option value="Kolkata"> Kolkata </option>
									 <option value="Pune"> Pune</option>
									  <option value="Bhopal"> Bhopal </option>
								
                            </select>
            </td>
			<td>
                            <select name="Designation4" required="required">
									<option value="JavaDeveloper"> Java Developer </option>
									<option value="FrontEndDeveloper"> FrontEnd Developer </option>
                                    <option value="BackEndDeveloper"> BackEnd Developer </option>
									 <option value="PhythonDeveloper"> Phython Developer </option>
									  <option value="SoftwareDeveloper"> Software Developer </option>
								
                            </select>
            </td>
                       
		</tr>
                <tr>
		<td colspan="7" align="center"><br><br>
		  <font color="black"><input type="submit" class="btn btn-primary" value="Submit">
		</td>
	</tr>
		
        </table>				
	</form>
 <?php include 'footer.php';?>