<?php 
$a = 'Fatber Christmas'; 
$b = '27 Sunshine Street /n America'; 
$c = nl2br($b); 
?> 
<html> 
<head> 
<script type="text/javascript"> 
function test(a,b) { 
    alert(a); 
    alert(b); 
} 
</script> 
</head> 
<body> 
<a onClick="test('<?php echo $a ?>', '<?php echo $c ?>');">LINK</a> 
</body> 
</html>