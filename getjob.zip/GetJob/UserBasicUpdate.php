<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
// Start the session
session_start();
?>
<?php include 'header.php';?>
<?php include 'navbar.php';?>


        <?php
   $host = 'localhost';  
$user = 'vinit';  
$pass = 'vinit';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

$EmailId="vinit@gmail.com";
$Name="vinit";
  $sql = "select * from userreg where Email='$EmailId'"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    $_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $name=$row['Name'];
    $Email=$row['Email'];
    $MobNo=$row['MobNo'];
    $Age=$row['Age'];
    $Gender=$row['Gender'];
    $PerAdd=$row['PerAdd'];
    $PerPin=$row['PerPin'];
    $State=$row['State'];
    $City=$row['City'];
    $AltEmail=$row['AltEmail'];
    $Country=$row['Country'];
      
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 

?>
       <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading"><label class="control-label"><?Php echo $Name; ?></label></div>

                <div class="panel-body">

                    <form class="form-horizontal" method="post" align="center" name="frmRegistration" action="UserBasicUpdateAction.php" >
        
    
	<table border="0" width="100%" cellpadding="5" >
        
           
       
         <tr>
             <td><label class="col-md-4 control-label">Email</label></td>
             <td><div class="col-md-6"><?Php echo $Email; ?></div></td>
        </tr>
       
	<tr>
		<td><font color="black"><label class="col-md-4 control-label"> Address</td>
		<td><font color="black">
                    <div class="col-md-6">
                        <textarea name="PerAdd" value="" class="form-control" rows="3" cols="16"  required="required">
                            <?Php echo $PerAdd; ?>
                        </textarea>
                    <br>
                    </div>
                </td>           
                
        </tr>
                
        <tr>
		
		<td><font color="black"><label class=" control-label"> Pin code </td>
                <td><font color="black">
                    <div class="col-md-6">
                   <input type="number" value="<?Php echo $PerPin; ?>" placeholder="Enter pin code" class="form-control" name="PerPin" required="required">
                    </div>
                </td>
	</tr>
	<tr>
		
		<td><font color="black"><label class="col-md-4 control-label"> Age </td>
                <td><font color="black">
                     <div class="col-md-6">
                         <input type="number" value="<?Php echo $Age; ?>" name="Age" class="form-control" size="3" required="required"></td>
                    </div>
                    </tr>
	<tr>
		
		<td><font color="black"><label class="col-md-4 control-label"> Gender </td>
		<td><font color="black">
                     <div class="col-md-6">
                         <?Php 
                         if($Gender=="Male")
                         {
                             ?>
                         <input type="radio" name="Gender" value="Male" checked="true"> Male
                         <input type="radio" name="Gender" value="Female"> Female</td>
                         <?Php
                         }
                         else
                         {
                            ?>
                          <input type="radio" name="Gender" value="Male"> Male
                          <input type="radio" name="Gender" value="Female" checked="true"> Female</td>
                         <?Php
                         }
                             ?>
                         
                        
                   </div>
                   </tr>


	<tr>
                
		<td><font color="black"> <label class="col-md-4 control-label">Country </td>
		<td><font color="black">
                    <div class="col-md-6">
                    <input type="text" value="<?Php echo $Country; ?>" name="Country" class="form-control" required="required">
                    </div>
                </td>
	</tr>
	<tr>
		
		<td><font color="black"><label class="col-md-4 control-label"> State</td>
		<td><font color="black">
                    <div class="col-md-6">
                    <input type="text" value="<?Php echo $State; ?>" name="State" class="form-control" required="required">
                    </div>
                </td>
	</tr>
	
	<tr>
		
		<td><font color="black"><label class="col-md-4 control-label"> City </td>
		<td><font color="black">
                    <div class="col-md-6">
                    <input type="text" value="<?Php echo $City; ?>" name="City" class="form-control" required="required">
                    </div>
                </td>
	</tr>

	<tr>
		
		<td><font color="black"><label class=" control-label"> Alternative Email ID</td>
		<td><font color="black">
                    <div class="col-md-6">
                    <input type="email" value="<?Php echo $AltEmail; ?>" name="AltEmail" class="form-control" size="50" required="required">
                    </div>
                </td>
	</tr>

          <tr>
		
		<td><font color="black"><label class="control-label">Mobile No</td>
                <td><font color="black">
                    <div class="col-md-6">
                    <input type="number" value="<?Php echo $MobNo; ?>" name="AltMobileNo" class="form-control" size="10" required="required">
                    </div>
                </td>
	</tr>
        
        <tr>
		<td colspan="3" align="center"><br><br>
		  <font color="black"><input type="submit" value="Submit" class="btn btn-primary">
		</td>
	</tr>

	</table>

    </form>
                </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php include 'footer.php';?>
    