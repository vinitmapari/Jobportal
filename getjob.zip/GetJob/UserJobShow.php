<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php
// Start the session
session_start();
?>
<?php include 'header.php';?>
<?php include 'navbaruser.php';?>
<?Php
$id=$_REQUEST['id'];
$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  

$Email=$_SESSION['Email'];


$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
$sql = "select * from jobpost where Id='$id'"; 
   $result = mysqli_query($conn,$sql);
   $row = mysqli_fetch_assoc($result);
   
   $Name=$row['Name'];
    $PrgLang=$row['PrgLang'];
    $Package=$row['Package'];
    $GradEdu=$row['GradEdu'];
    $PostGradEdu=$row['PostGradEdu'];
    $Venue=$row['Venue'];
    $Date=$row['Date'];       
    $Time=$row['Time'];    

     $_SESSION['Name1']=$Name;
     //echo  $_SESSION['Name'];
    $_SESSION['PrgLang']=$PrgLang;
    $_SESSION['Venue']=$Venue;
    $_SESSION['Date']=$Date;      
    $_SESSION['Time']=$Time;        
    $_SESSION['Package']=$Package;
    $_SESSION['Id']=$id;
?>
<br><br>

<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Job Details</div>

                <div class="panel-body">
                    <form class="form-horizontal" method="POST" action="UserJobAddAction.php">
                       

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Job Post</label>

                            <div class="col-md-6">
                                
                                <label for="name" class="col-md-4 control-label"><?Php echo $Name; ?></label>
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">Education Requirement Graduation</label>

                            <div class="col-md-6">
                               <label for="name" class="col-md-4 control-label"><?Php echo $GradEdu; ?></label>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">Education Requirement Post Graduation</label>

                            <div class="col-md-6">
                                <label for="name" class="col-md-4 control-label"><?Php echo $PostGradEdu; ?></label>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="email" class="col-md-4 control-label">Pragramming Language Known</label>

                            <div class="col-md-6">
                                <label for="name" class="col-md-4 control-label"><?Php echo $PrgLang; ?></label>
                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                                
                            </div>
                        </div>

                        

                        <div class="form-group">
                            <label for="password-confirm" class="col-md-4 control-label">Venue</label>

                            <div class="col-md-6">
                                <label for="name" class="col-md-4 control-label"><?Php echo $Venue; ?></label>
                           <span class="help-block">
                                        <strong><span id='message'></span></strong>
                                    </span>
                               
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Package</label>

                            <div class="col-md-6">
                               <label for="name" class="col-md-4 control-label"><?Php echo $Package; ?></label>

                                
                                    <span class="help-block">
                                        <strong></strong>
                                    </span>
                               
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Date of Interview</label>

                            <div class="col-md-6">
                                <label for="name" class="col-md-4 control-label"><?Php echo $Date; ?></label>
                               
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="name" class="col-md-4 control-label">Time</label>

                            <div class="col-md-6">
                                <label for="name" class="col-md-4 control-label"><?Php echo $Time; ?></label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    share
                                </button>
                                <a href="UserJobList.php?Email=<?Php echo $Email; ?>">Back</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<br><br>
<?php include 'footer.php';?>


