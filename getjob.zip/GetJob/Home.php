<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
    <head>
    <?php include 'header.php';?>
<?php include 'navbar.php';?>
 <?php include 'slider.php';?>   
        <br>
<?php include 'HomeMidContent.php';?>   
        <br><br>
<?php include 'footer.php';?>

       
        