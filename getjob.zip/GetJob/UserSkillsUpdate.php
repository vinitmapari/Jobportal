<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php include 'header.php';?>
<?php include 'navbaruser.php';?>
<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

$EmailId="vinit@gmail.com";

  $sql = "select * from userskills where Email='$EmailId'"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    $_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   $numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $prglang=$row['prglang'];
    $project1=$row['project1'];
    $project2=$row['project2'];
    $project3=$row['project3'];
    $LangInt=$row['LangInt'];
    $Hobbies=$row['Hobbies'];

      
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 

?>
<form  method="post" align="center" name="frmRegistration" action="UserSkillsUpdateAction.php" >
        
    <u><center><font size="20" color="RED" >User skills</font></center></u>
	<table border="1" width="100%" cellpadding="5" align="center">
        
        <tr>
	<th colspan="2"><font size="5" color="black">please fill the following</font></th>
	</tr>
	
        <tr>
            
            <td>Programming launguages </td>
            <td><textarea name="prglang" rows="8" cols="64"  required="required"><?Php echo $prglang; ?></textarea></td>
        </tr>
        
         <tr>
            <td>Last 3 projects</td>
            <td>1.<input type="text" name="project1" required="required" value="<?Php echo $project1; ?>">
             2.<input type="text" name="project2" required="required" value="<?Php echo $project2; ?>">
              3.<input type="text" name="project3" required="required" value="<?Php echo $project3; ?>"></td>
        </tr>
        
         <tr>
            <td>Languages that you are interested in</td>
            <td><textarea name="LangInt" rows="8" cols="64"  required="required"><?Php echo $LangInt; ?></textarea></td>
        </tr>
        
         <tr>
            <td>Hobbies</td>
            <td><textarea name="Hobbies" rows="8" cols="64"  required="required"><?Php echo $Hobbies; ?></textarea></td>
        </tr>
        
	<tr>
            <td colspan="4"><br><br>
		  <input type="submit" class="btn btn-primary" value="Submit">
            </td>
        </tr>
	</table>


    </form>
    <?php include 'footer.php';?>	