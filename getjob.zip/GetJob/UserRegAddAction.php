
<?php  
$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  


$name=$_POST['name'];
$email = $_POST['email'];
$Passwd = $_POST['password'];

$sql = "INSERT INTO userreg (Name,Email,Passwd) VALUES ('$name','$email','$Passwd')"; 
if(mysqli_query($conn, $sql)){  
   header('Location: UserLogin.php'); 
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  
  
mysqli_close($conn);  
?>  


