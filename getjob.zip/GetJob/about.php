<?php include 'header.php';?>
<?php include 'navbar.php';?>
<center>
	<div class="entry-content" id="box1">
            
            <p>In recent years, many studies conducted by organizations like NASSCOM, CII and FICCI have shown that employability of graduates in India is quite low. If we compare these observations with predictions made by same organizations about increasing need of skilled workforce, we see a big gap. This gap can be filled in by providing right training to young graduates for enhancing their employability skills.</p>
<p>Employability is not about getting job; rather it implies ability of a person to effectively function in a job and remain employed (either as corporate employee or self-employed) throughout his/her working life.</p></blockquote>
             <p>We have set up Vidyarjan Consulting Pvt. Ltd. to help graduates become employable. We believe that graduates should learn beyond what was taught in school and colleges to make themselves employable. We offer both open courses and corporate training programs to address this need.</p>
	</div>

</center>

<br><br>
<?php include 'footer.php';?>
<style>
#box1
{
    width: 900px;
    padding: 10px;
    border: 5px solid gray;
    margin: 0; 
}
p {
    font-family: "Times New Roman", Times, serif;
    font-size: 20px;
}

</style>
