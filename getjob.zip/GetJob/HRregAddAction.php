
<?php  
$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  


$name=$_POST['name'];
$email = $_POST['email'];
$Passwd = $_POST['password'];
$MobNo=$_POST['MobNo'];
$Country = $_POST['Country'];
$State = $_POST['State'];
$City = $_POST['City'];


$sql = "INSERT INTO hrreg (Name,Email,MobNo,Password,Country,State,City) VALUES ('$name','$email','$MobNo','$Passwd','$Country','$State','$City')"; 
if(mysqli_query($conn, $sql)){  
   header('Location: HRLogin.php'); 
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  
  
mysqli_close($conn);  
?>  


