<?php include 'header.php';?>
<?php include 'navbaradmin.php';?>
<div class="container">
  <h2>User Applied List</h2>
  
  <table class="table">
    <thead>
      <tr>
        <th>Email Id</th>
        <th>Post</th>
        <th>Programming language</th>
        <th>package</th>
	<th>Venue</th>
        <th>Date</th>
        <th>Time</th>
        <th>View</th>
      </tr>
    </thead>
	
	<tbody>
            <?php  
$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

$sql1 = "select * from userapply";
  $result1=mysqli_query($conn, $sql1);
 while ($row = mysqli_fetch_assoc($result1)) 
{
     $Email=$row['email'];
    $Name1=$row['Name'];
    $PrgLang=$row['prglang'];
    $Package=$row['Package'];
    $Venue=$row['venue'];
    $Date=$row['Date'];       
    $Time=$row['time'];  
?>
	
      <tr>
        <td><?Php echo $Email; ?></td>
        <td><?Php echo $Name1; ?></td>
        <td><?Php echo $PrgLang; ?></td>
        <td><?Php echo $Package; ?></td>
         <td><?Php echo $Venue; ?></td>
         <td><?Php echo $Date; ?></td>
         <td><?Php echo $Time; ?></td>
         <td><a href="HRUserBasicProfile.php?Email=<?Php echo $row['email']; ?>">View</a></td>
      </tr>
      
     
  <?Php  
}
?>
</tbody>
  </table>
<?php include 'footer.php';?>  

