<html>
<head>
	<meta http:equiv="content-type" content="text/html"; charset="utf-8";>
		<link rel="stylesheet" type="text/css" href="Styles.css">
		</head>
		<body>
		<div class="container dark">
			<div class="wraapper" id=top-div>
			<div id="top-left">
				 Email id: anurag.narkhede@gmail.com
			</div>
			<div id="top-right">
				Mobile no:- 9594194008
			</div>
			<div id="clear">
			</div>
		</div>
		
		<div class="container light">
		<div class="wraapper">
		<div id="logo-left">
			<img src="https://www.baapoffers.com/images/logo.png">
		
		</div>
		<div id="logo-right">
			<form>
				<input id="textstyle" type="text" name="textbox"/>
				<input id="button" type="button" name="search" value="search"/>
			</form>
		</div>
		<div id="clear">
			</div>
		</div>
			
		<div class="container dark">
			<div class="wraapper">
			<ul>
			<li><a href="main.php"> Home</a></li>
			<li><a href="carrer.php">carrer</a></li>
			<li><a href="about.php">About us</a></li>
			
		</ul>
		<div class="container light">
			<div class="wraapper">
		<pre>
					welcome to php website
		
		</pre>
		
			</div>
		</div>
		
		</head>
		</html>
		<?php include_once'footer.php'; ?>
	
	