<?php  

session_start();
//$Email="vinit@gmail.com";
$Email=$_SESSION["Email"];

$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  




$Companyname1 = $_POST['Companyname1'];
$CompanyAddress1 = $_POST['CompanyAddress1'];
$Experience1 = $_POST['Experience1'];
$JobLocation1 = $_POST['JobLocation1'];
$Designation1 = $_POST['Designation1'];

$Companyname2 = $_POST['Companyname2'];
$CompanyAddress2 = $_POST['CompanyAddress2'];
$Experience2 = $_POST['Experience2'];
$JobLocation2 = $_POST['JobLocation2'];
$Designation2 = $_POST['Designation2'];

$Companyname3 = $_POST['Companyname3'];
$CompanyAddress3 = $_POST['CompanyAddress3'];
$Experience3 = $_POST['Experience3'];
$JobLocation3 = $_POST['JobLocation3'];
$Designation3 = $_POST['Designation3'];

$Companyname4 = $_POST['Companyname4'];
$CompanyAddress4 = $_POST['CompanyAddress4'];
$Experience4 = $_POST['Experience4'];
$JobLocation4 = $_POST['JobLocation4'];
$Designation4 = $_POST['Designation4'];

$sql="Insert Into userwork (Email,Companyname1,CompanyAddress1,Experience1,JobLocation1,Designation1,
    Companyname2,CompanyAddress2,Experience2,JobLocation2,Designation2,
    Companyname3,CompanyAddress3,Experience3,JobLocation3,Designation3,
    Companyname4,CompanyAddress4,Experience4,JobLocation4,Designation4)
        values('$Email','$Companyname1','$CompanyAddress1','$Experience1','$JobLocation1','$Designation1',
        '$Companyname2','$CompanyAddress2','$Experience2','$JobLocation2','$Designation2',
        '$Companyname3','$CompanyAddress3','$Experience3','$JobLocation3','$Designation3',
        '$Companyname4','$CompanyAddress4','$Experience4','$JobLocation4','$Designation4');";
//$sql = "Update userskills set email='$prglang',project1='$project1',project2='$project2',project3='$project3',LangInt='$LangInt',Hobbies='$Hobbies' where email='$Email';"; 
if(mysqli_query($conn, $sql)){  
 
 header('Location: UserFormBasicProfile.php'); 
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  
  
mysqli_close($conn);  
?>  




