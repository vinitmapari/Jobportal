<?php
// Start the session
session_start();
?>

<?php include 'header.php';?>
<?php include 'navbaruser.php';?>
<?php
// Start the session
$Name=$_SESSION["Name"];
$Email=$_SESSION["Email"];

?>

            
<?php include 'footer.php';?>	




