<?php
// Start the session
session_start();
?>
<?php include 'header.php';?>
<?php include 'navbaruser.php';?>
<div class="container">
<div class="col-md-8 col-lg-8">
<?php

   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  //$Email=$_SESSION["Email"];
$Email=$_REQUEST['Email'];
$_SESSION['Email']=$Email;
  //echo $Email;
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  

$sql = "select * from userreg where Email='$Email'"; 
   $result = mysqli_query($conn,$sql);
   $row = mysqli_fetch_assoc($result);
 $Name=$row['Name'];
 $_SESSION["Name"]=$Name;


$sql = "select * from useredu where EmailId='$Email'"; 
   $result = mysqli_query($conn,$sql);
   $row = mysqli_fetch_assoc($result);
 $Grad=$row['G_degree'];
    $PG=$row['P_degree'];
//echo 'Connected successfully<br/>'; 
//$Grad="BSC";
//$PG="";
//$PG="MSC";
if($PG=="")
{
   $sql = "select * from jobpost where GradEdu='$Grad' and PostGradEdu='' "; 
   $result = mysqli_query($conn,$sql);
   while ($row = mysqli_fetch_assoc($result)) 
{
     
    $Name=$row['Name'];
    $PrgLang=$row['PrgLang'];
    $Package=$row['Package'];
    
   ?>
        
        

    
<ul class="list-group">
    <li class="list-group-item">Name:<?Php echo $Name; ?></li> 
    <li class="list-group-item">Programming Languages Known :<?Php echo $PrgLang; ?></li> 
    <li class="list-group-item">Package:<?Php echo $Package; ?></li> 
    <li><a href="UserJobShow.php?id=<?Php echo $row['Id']; ?>">View</a></li>
</ul>
    

        <?Php
    
      
}


?>
	</div>
<div class="col-md-4 col-lg-4">
    <h1></h1>
</div>
</div>
<?Php
}
else
{
    $sql = "select * from jobpost where GradEdu='$Grad' and PostGradEdu='$PG'";
    $result = mysqli_query($conn,$sql);
    while ($row = mysqli_fetch_assoc($result)) 
{
    $Name=$row['Name'];
    $PrgLang=$row['PrgLang'];
    $Package=$row['Package'];
    
   ?>
        
        

    
<ul class="list-group">
    <li class="list-group-item">Name:<?Php echo $Name; ?></li> 
    <li class="list-group-item">Email:<?Php echo $PrgLang; ?></li> 
    <li class="list-group-item">Package:<?Php echo $Package; ?></li>
     <li><a href="UserJobShow.php?id=<?Php echo $row['Id']; ?>">View</a></li>
</ul>
    

        <?Php
    
      
}


?>
	</div>
<div class="col-md-4 col-lg-4">
    <h1></h1>
</div>
</div>
<?Php
}

  //$sql = "select * from jobpost"; 
  //var_dump($sql); 

  
   
    //$result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   ?>
    <?php include 'footer.php';?>

