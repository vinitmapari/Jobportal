<?php

require_once 'config.php';

if(isset($_SESSION['access_token']))
    $gClient->setAccessToken($_SESSION['access_token']);
else if(isset($_GET['code']))
{
    $token=$gClient->fetchAccessTokenWithAuthCode($_GET['code']);
    $_SESSION['access_token']=$token;
}
else
{
    header('Location:UserLogin.php');
    exit();
}
$oAuth=new Google_Service_Oauth2($gClient);
$userData=$oAuth->userinfo_v2_me->get();

$_SESSION['Email']=$userData['email'];
$_SESSION['gender']=$userData['gender'];
$_SESSION['picture']=$userData['picture'];
$_SESSION['familyName']=$userData['familyName'];
$_SESSION['Name']=$userData['givenName'];
$EmailId=$_SESSION['Email'];
$Name=$_SESSION['Name'];

$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>'; 

 
$sql1 = "select * from userreg where Email='$EmailId'"; 
  //var_dump($sql); 
//if(mysqli_query($conn, $sql))
//{  
   
    $result = mysqli_query($conn,$sql1);
    $_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //echo $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $name=$row['Name'];
    $Email=$row['Email'];
    $PerAdd=$row['PerAdd'];
    $_SESSION["Name"] = "$name";
   
    
 
    
}

if($name=="")
{
 $sql = "INSERT INTO userreg (Name,Email) VALUES ('$Name','$EmailId')"; 
    mysqli_query($conn, $sql); 
   
}
//echo $PerAdd;
  //echo $name;   
   
//}
//else
//{  
  //  echo '0';
//}  
 
 $sql = "select * from userwork where Email='$EmailId'"; 
  //var_dump($sql); 
//if(mysqli_query($conn, $sql))
//{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //echo $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $companyname=$row['Companyname1'];
    echo $companyname;
}

$sql = "select * from userskills where Email='$EmailId'"; 
  //var_dump($sql); 
//if(mysqli_query($conn, $sql))
//{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //echo $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $LangInterest=$row['LangInt'];
    //$Email=$row['Email'];
    //$_SESSION["Name"] = "$name";
    echo $LangInterest;
    
 
    
}
$sql2 = "select * from useredu where EmailId='$EmailId'"; 
  //var_dump($sql); 
//if(mysqli_query($conn, $sql))
//{  
   
    $result = mysqli_query($conn,$sql2);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //echo $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $csname=$row['S_csname'];
    //$Email=$row['Email'];
    //$_SESSION["Name"] = "$name";
    echo $csname;
    
 
    
}


       
   if($PerAdd=='')
   {
    header('Location: UserFormBasic.php'); 
   }
   elseif($csname=='')
   {
       header('Location: UserFormEdu.php'); 
   }
    elseif($LangInterest=='')
   {
       header('Location: UserFormSkills.php'); 
   }  
 elseif($companyname=='')
   {
       header('Location: UserFormWork.php'); 
   }
   else
   {
      header('Location: UserFormBasicProfile.php');  
   }


 //header('Location: UserFormBasicProfile.php'); 


?>
