<?php  

session_start();


$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  




$Name = $_POST['Name'];
$Email = $_POST['Email'];
$Message = $_POST['Feedback'];

$sql="Insert Into feedback (name,email,feedback)
        values('$Name','$Email','$Message');";
//$sql = "Update userskills set email='$prglang',project1='$project1',project2='$project2',project3='$project3',LangInt='$LangInt',Hobbies='$Hobbies' where email='$Email';"; 
if(mysqli_query($conn, $sql)){  
 
 header('Location: FeedbackUser.php'); 
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  
  
mysqli_close($conn);  
?>  




