<?php
// Start the session
//session_start();
?>
<?php include 'header.php';?>
<?php include 'navbaradmin.php';?>
<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

$EmailId=$_REQUEST['Email'];
//echo $EmailId;
//$_SESSION["Email3"] = "$EmailId";
  $sql = "select * from userskills where Email='$EmailId'"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $prglang=$row['prglang'];
    $project1=$row['project1'];
    $project2=$row['project2'];
    $project3=$row['project3'];
    $LangInt=$row['LangInt'];
    $Hobbies=$row['Hobbies'];

      
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 

?>
<form  method="post" align="center" name="frmRegistration" action="HRUserWorkProfile.php?Email=<?Php echo $EmailId; ?>" >
        
    <u><center><font size="20" color="RED" >User skills</font></center></u>
	<table border="1" width="100%" cellpadding="5" align="center">
	
        <tr>
            
            <td>Programming launguages </td>
            <td><?Php echo $prglang; ?></td>
        </tr>
        
         <tr>
            <td>Last 3 projects</td>
            <td>1.<?Php echo $project1; ?>
             2.<?Php echo $project2; ?>
              3.<?Php echo $project3; ?></td>
        </tr>
        
         <tr>
            <td>Languages that you are interested in</td>
            <td><?Php echo $LangInt; ?></td>
        </tr>
        
         <tr>
            <td>Hobbies</td>
            <td><?Php echo $Hobbies; ?></td>
        </tr>
        
	<tr>
            <td colspan="4"><br><br>
		  <input type="submit" class="btn btn-primary" value="Next">
                  <a href="HRUserEduProfile.php?Email=<?Php echo $EmailId;?>">Back</a>
                  <a href="UserSkillsUpdate.php?Email=<?Php echo $EmailId;?>">Update</a>
            </td>
        </tr>
	</table>


    </form>
    <?php include 'footer.php';?>

