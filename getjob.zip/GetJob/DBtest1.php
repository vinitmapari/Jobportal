<html>
   
   <head>
      <title>Sending HTML email using PHP</title>
   </head>
   
   <body>
      
      <?php
                 
         mail ('vinitmapari@gmail.com','sample mail','sample content','From: vinitmapari@gmail.com');
         
         
            
         
      ?>
      
   </body>
</html>