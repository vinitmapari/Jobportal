<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php $title ?> </title>
    <link rel="stylesheet" type="text/css" href="StyleSheet.css" />
</head>
<body>
   
        <div id="wrapper">
           <div id="banner">
               
          </div>     
           
           <nav id="navigator">
             <ul id="nav">  
                 <li><a href="index.php">Home</a></li>
                 <li><a href="">carrer</a></li>
				 <li><a href="">Projects</a>
				 <div style="width: 50%;float: left;">					
				 
				<div><a style="margin: 5%;color: #fff;text-decoration: none" href=""></a>Local Project</div>
				 
				<div><a style="margin: 5%;color: #fff;text-decoration: none" href=""></a>National Project</div>
				<div><a style="margin: 5%;color: #fff;text-decoration: none" href=""></a>InterNational Project</div>
				</li>
                 <li><a href="">About us</a></li>
             </ul>
           </nav>
           <h2 class="slideshow">Automatic Slideshow</h2>

<div class="styleclass" style="max-width:500px">
  <img class="mySlides" src="planttree.jpg" style="width:100%">
  <img class="mySlides" src="power.jpg" style="width:100%">
  <img class="mySlides" src="planttree.jpg" style="width:100%">
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 2000); 
}
</script>

           <div id="content_area">
               
           </div>
            <div id="sidebar">
			</div>
			
			<footer>
			 <div class="footer">
		<div>Job Protal</div>
		<div style="padding-top: 5%;"><a href="About_us.html">About Us</a></div>
		<div><a href="Project.html">Reward Store</a></div>
		<div><a href="Contact_us.html">Contact Us</a></div>
	</div>
	<div style="float: left;width :35%;">
		<div>Suscribe to Job Portal</div>
        <div><input type="text" id="emailId" name="email" class="newsletter_input" value="your email"/>
        <input type="button" name="subscribe" value="SUBSCRIBE" onclick="subscribe()" class="styled-button-5"></div>
		
	</div>
	<div style="float: left;width :25%;">
		<div>Follow Us on Social Media</div>
		<div class="socialMedia">
		<label class="facebookDiv"><a target="_blank" href="https://www.facebook.com/anuragnarkhede/">
		<img src="https://www.baapoffers.com/images/facebook.png" alt="Facebook" style="width: 35px;" />
		</a></label>
		<label class="twitterDiv"><a target="_blank" href="https://twitter.com/anuragnarkhede1">
		<img src="https://www.baapoffers.com/images/twitter.png" alt="twitter" style="width: 35px;"/>
		</a></label>
		<label class="googleDiv"><a target="_blank" href="https://plus.google.com/u/0/117515715085714607552">
		<img src="https://www.baapoffers.com/images/google-plus.png" alt="Google" style="width: 35px;"/>
		</a></label>
		<label class="instaDiv"><a target="_blank"  href="https://www.instagram.com/anuragnarkhede/">
		<img src="https://www.baapoffers.com/images/instagram.png" alt="instagram" style="width: 35px;"/>
		</a></label>
		</div>
	</div>
			</footer>
            
    </body>
</html>