<?php include 'header.php';?>
<?php include 'navbar.php';?>
<form name='' action="FeedbackUserAddAction.php" method="POST">

<div class="container">
    <div class="col-md-8 col-lg-8">
         <div class="panel panel-default">
                <div class="panel-heading">Feedback</div>

                <div class="panel-body">
<div class="form-group">
    <label name=''>Name</label>
    <input type="text" class='form-control' name="Name" placeholder='Enter name'>
    
</div>

<div class="form-group">
     <label name=''>Email</label>
     <input type="email" class='form-control' placeholder='Enter name' name="Email">
</div>

<div class="form-group">
     <label name=''>Feedback</label>
     <textarea class='form-control' rows="10" cols="16" placeholder='Enter name' name="Feedback"></textarea>
</div>
<div>
    <input type="submit" class="btn btn-primary">
</div>
    </div>
    
                </div>
        </div>
   
<div class="col-md-4 col-lg-4">
    <font size="6"> <b><center>Our Best Review</center></b></font>
       <div class="myBox">
           <?php
            $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

  $sql = "select * from feedback where feedback LIKE '%best%' OR feedback LIKE"
          . "  '%good%' OR feedback LIKE '%excellent%' LIMIT 4"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $name=$row['name'];
    $email=$row['email'];
    $feedback=$row['feedback'];
    
   ?>
        
        

  
<ul class="list-group">
  
    <li class="list-group-item" style="color: black; background:transparent; background-color:silver ">Name:<?Php echo $name; ?></li>
    <li class="list-group-item" style="color: black; background:transparent; background-color:lightgray ">Email:<?Php echo $email; ?></li> 
    <li class="list-group-item" style="color: black; background:transparent; background-color:gainsboro ">Message:<?Php echo $feedback; ?></li> 
</ul>
        


        <?Php
    
      
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 ?>
       </div>

    </div>
</div>
</form>
<br><br>

<?php include 'footer.php';?>