<?php  

session_start();
$Email=$_SESSION["Email"];

$host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
echo 'Connected successfully<br/>';  




$prglang = $_POST['prglang'];
$project1 = $_POST['project1'];
$project2 = $_POST['project2'];
$project3 = $_POST['project3'];
$LangInt = $_POST['LangInt'];
$Hobbies = $_POST['Hobbies'];

$sql="Insert Into userskills (email,prglang,project1,project2,project3,LangInt,Hobbies)
        values('$Email','$prglang','$project1','$project2','$project3','$LangInt','$Hobbies');";
//$sql = "Update userskills set email='$prglang',project1='$project1',project2='$project2',project3='$project3',LangInt='$LangInt',Hobbies='$Hobbies' where email='$Email';"; 
if(mysqli_query($conn, $sql)){  
 
 header('Location: UserFormWork.php'); 
}else{  
echo "Could not insert record: ". mysqli_error($conn);  
}  
  
mysqli_close($conn);  
?>  




