<?php include 'header.php';?>
<?php include 'navbar.php';?>
 <form  method="post" align="center" name="frmRegistration" action="UserFormEduAddAction.php" >
        
    <u><center><font size="20" color="RED" > User view this</font></center></u>
	<table border="1" width="100%" cellpadding="5" >
        

		<tr>
			
			<th>Name</th>
			<th>Email </th>
			<th>Graduation</th>
                        <th>Post Graduation</th>
			<th>Skills</th>
			<th>Intested Language</th>
			
                        
		</tr>
<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  

$EmailId="vinit@gmail.com";

  $sql1 = "select * from userreg where Email='$EmailId'"; 
  $sql2 = "select * from useredu where EmailId='$EmailId'"; 
  $sql3 = "select * from userwork where Email='$EmailId'"; 
  $sql4 = "select * from userskills where email='$EmailId'"; 
  //var_dump($sql); 
 
   
    $result1 = mysqli_query($conn,$sql1);
    $result2 = mysqli_query($conn,$sql2);
    $result3 = mysqli_query($conn,$sql3);
    $result4 = mysqli_query($conn,$sql4);
    
    $_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   //while ($row1 = mysqli_fetch_assoc($result1) && $row2 = mysqli_fetch_assoc($result2) 
           //&& $row3 = mysqli_fetch_assoc($result3) && $row4 = mysqli_fetch_assoc($result4)) 
//{
    $row1 = mysqli_fetch_assoc($result1);
    $row2 = mysqli_fetch_assoc($result2);
    $row3 = mysqli_fetch_assoc($result3);
    $row4 = mysqli_fetch_assoc($result4);
    $Name=$row1['Name'];
    $Email=$row1['Email'];
    $S_degree=$row2['S_degree'];
    $H_degree=$row2['H_degree'];
    $prglang=$row4['prglang'];
    $LangInt=$row4['LangInt'];
    
    ?>
                
  <tr>
			
			<td><?Php echo $Name;?></td>
			<td><?Php echo $Email;?></td>
			<td><?Php echo $S_degree;?></td>
			<td><?Php echo $H_degree;?></td>
			<td><?Php echo $prglang;?></td>
                        <td><?Php echo $LangInt;?></td>
                        
    </tr>
              
                
                
 <?Php                
  
//}

?>
        </table>
 </form>
       
    <?php include 'footer.php';?>



