<?php
session_start();

if(!isset($_SESSION['access_token']))
{
    header('Location:UserLogin.php');
    exit();
}


?>
<?php

echo $_SESSION['email'];

echo $_SESSION['gender'];

echo $_SESSION['familyName'];

echo $_SESSION['givenName'];


?>
<html>
    <body>
        <img src="<?php echo $_SESSION['picture'] ?>" alt="ProfileName">
    </body>
</html>