<?php

session_start();
require_once 'GoogleAPI/vendor/autoload.php';
$gClient=new Google_Client();
$gClient->setClientId("742645727198-8ae0tr4a7sollompmj88mtv283ugf2ea.apps.googleusercontent.com");
$gClient->setClientSecret("XfefdVAaOklujEvy237lLUkE");
$gClient->setApplicationName("VidyarjanLogin");
$gClient->setRedirectUri("http://localhost/GetJob/gCallback.php");
$gClient->setScopes("https://www.googleapis.com/auth/plus.login https://www.googleapis.com/auth/userinfo.email");

?>
