<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="css/app.css">
        <link rel="stylesheet" href="midcontent.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>

<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</head>
  
  <style>
/* Force scrollbars onto browser window */

/* Box styles */
.myBox {
border: none;
padding: 5px;
font: 24px/36px sans-serif;
width: 450px;
height: 450px;
overflow: scroll;
}

.myBox1 {
border: none;
padding: 5px;
font: 24px/36px sans-serif;
width: 450px;
height: 450px;
overflow: scroll;
}

/* Scrollbar styles */
::-webkit-scrollbar {
width: 12px;
height: 12px;
}

::-webkit-scrollbar-track {
border: 1px solid DarkGray;
border-radius: 10px;
}

::-webkit-scrollbar-thumb {
background: DarkGray;  
border-radius: 10px;
}

::-webkit-scrollbar-thumb:hover {
background: DarkGray;  
}
</style>
 
   
    <body>
        <div class="well">
        <img width="240" height="118" 
        src="http://www.vidyarjanconsulting.in/wp-content/uploads/2016/05/cropped-logo-with-caption.png" 
        class="custom-logo" alt="cropped-logo-with-caption.png" itemprop="logo" />
        </div>
        
