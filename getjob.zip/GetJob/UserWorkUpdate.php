<?php
// Start the session
session_start();
?>


<?php include 'header.php';?>
<?php include 'navbaruser.php';?>
<?php
   $host = 'localhost';  
$user = 'root';  
$pass = '';  
$dbname = 'jobrecruit';  
  
$conn = mysqli_connect($host, $user, $pass,$dbname);  
if(!$conn){  
  die('Could not connect: '.mysqli_connect_error());  
}  
//echo 'Connected successfully<br/>';  
$EmailId="vinit@gmail.com";
//$EmailId=$_SESSION["Email"];
//$EmailId=$_REQUEST['Email'];

  $sql = "select * from userwork where Email='$EmailId'"; 
  //var_dump($sql); 
if(mysqli_query($conn, $sql))
{  
   
    $result = mysqli_query($conn,$sql);
    //$_SESSION["Email"] = "$EmailId";
    //var_dump($result); 
    //echo $_SESSION["Email"];
    //$_SESSION["User"] = $result;
   //$numrows=mysqli_num_rows($result);
   //ec ho $numrows;
   while ($row = mysqli_fetch_assoc($result)) 
{
    $Companyname1=$row['Companyname1'];
    $CompanyAddress1=$row['CompanyAddress1'];
    $Experience1=$row['Experience1'];
    $JobLocation1=$row['JobLocation1'];
    $Designation1=$row['Designation1'];
    
    $Companyname2=$row['Companyname2'];
    $CompanyAddress2=$row['CompanyAddress2'];
    $Experience2=$row['Experience2'];
    $JobLocation2=$row['JobLocation2'];
    $Designation2=$row['Designation2'];
    
    $Companyname3=$row['Companyname3'];
    $CompanyAddress3=$row['CompanyAddress3'];
    $Experience3=$row['Experience3'];
    $JobLocation3=$row['JobLocation3'];
    $Designation3=$row['Designation3'];
    
    $Companyname4=$row['Companyname4'];
    $CompanyAddress4=$row['CompanyAddress4'];
    $Experience4=$row['Experience4'];
    $JobLocation4=$row['JobLocation4'];
    $Designation4=$row['Designation4'];
      
}


   
     
    
   
}
else
{  
    echo '0';
}  
  
 

?>
<form method="POST" action="UserWorkUpdateAction.php">
<u><center><font size="20" color="RED" > WORK Expirence</font></center></u>
	<table border="1" width="100%" cellpadding="5" >
        
        <tr>
	<th colspan="10"><font size="5" color="black">please fill the following</font></th>
	</tr>

	<tr>
			<th></th>
			<th>Company Name</th>
			<th>Company Area Name</th>
			<th>Expirence</th>
			<th>Job Location</th>
			<th>Designation</th>
                        
	</tr>

		<tr>
			<td>1</td>
                      
			<td><input type="textarea" name="Companyname1" required="required" value="<?Php echo $Companyname1; ?>"></td>
			<td><input type="textarea" name="CompanyAddress1" required="required" value="<?Php echo $CompanyAddress1; ?>"></td>
                        <td><input type="number" name="Experience1" required="required" maxlength="10" size="10"value="<?Php echo $Experience1; ?>"></td>
			
			<td>
                            <select name="JobLocation1" required="required" value="<?Php echo $JobLocation1;  ?>">
									<option value="Mumbai"> Mumbai </option>
									<option value="Delhi"> Delhi</option>
                                                                        <option value="Kolkata"> Kolkata </option>
									 <option value="Pune"> Pune</option>
									  <option value="Bhopal"> Bhopal </option>
								
                            </select>
                        </td>
			
			<td>
                            <select name="Designation1" required="required" value="<?Php echo $Designation1; ?>">
									<option value="JavaDeveloper"> Java Developer </option>
									<option value="FrontEndDeveloper"> FrontEnd Developer </option>
                                                                        <option value="BackEndDeveloper"> BackEnd Developer </option>
									 <option value="PhythonDeveloper"> Phython Developer </option>
									  <option value="SoftwareDeveloper"> Software Developer </option>
								
                            </select>
                        </td>
			
                        
		</tr>

		<tr>
			<td>2</td>
                      
			<td><input type="textarea" name="Companyname2" required="required" value="<?Php echo $Companyname2; ?>"></td>
			<td><input type="textarea" name="CompanyAddress2" required="required" value="<?Php echo $CompanyAddress2; ?>"></td>
                        <td><input type="number" name="Experience2" required="required" maxlength="4" size="4" value="<?Php echo $Experience2; ?>"></td>
			
			<td>
                            <select name="JobLocation2" required="required" value="<?Php echo $JobLocation2;  ?>">
									<option value="Mumbai"> Mumbai </option>
									<option value="Delhi"> Delhi</option>
                                    <option value="Kolkata"> Kolkata </option>
									 <option value="Pune"> Pune</option>
									  <option value="Bhopal"> Bhopal </option>
								
                            </select>
            </td>
			<td>
                            <select name="Designation2" required="required" value="<?Php echo $Designation2; ?>">
									<option value="JavaDeveloper"> Java Developer </option>
									<option value="FrontEndDeveloper"> FrontEnd Developer </option>
                                                                        <option value="BackEndDeveloper"> BackEnd Developer </option>
									 <option value="PhythonDeveloper"> Phython Developer </option>
									  <option value="SoftwareDeveloper"> Software Developer </option>
								
                            </select>
            </td>
			
                       
		</tr>
		
		<tr>
			<td>3</td>
                        
			<td><input type="textarea" name="Companyname3" required="required" value="<?Php echo $Companyname3; ?>"></td>
			<td><input type="textarea" name="CompanyAddress3" required="required" value="<?Php echo $CompanyAddress3; ?>"></td>
                        <td><input type="number" name="Experience3" required="required" maxlength="10" size="10" value="<?Php echo $Experience3; ?>"></td>
			
			<td>
                            <select name="JobLocation3" required="required" value="<?Php echo $JobLocation3;  ?>">
									<option value="Mumbai"> Mumbai </option>
									<option value="Delhi"> Delhi</option>
                                                                        <option value="Kolkata"> Kolkata </option>
									 <option value="Pune"> Pune</option>
									  <option value="Bhopal"> Bhopal </option>
								
                            </select>
            </td>
			<td>
                            <select name="Designation3" required="required" value="<?Php echo $Designation3; ?>">
									<option value="JavaDeveloper"> Java Developer </option>
									<option value="FrontEndDeveloper"> FrontEnd Developer </option>
                                    <option value="BackEndDeveloper"> BackEnd Developer </option>
									 <option value="PhythonDeveloper"> Phython Developer </option>
									  <option value="SoftwareDeveloper"> Software Developer </option>
								
                            </select>
            </td>
                        		</tr>
		
		<tr>
			<td>4</td>
                       
            <td><input type="textarea" name="Companyname4" required="required" value="<?Php echo $Companyname4; ?>"></td>
			<td><input type="textarea" name="CompanyAddress4" required="required" value="<?Php echo $CompanyAddress4; ?>"></td>
                        <td><input type="number" name="Experience4" required="required" maxlength="4" size="4" value="<?Php echo $Experience4; ?>"></td>
			
			<td>
                            <select name="JobLocation4" required="required" value="<?Php echo $JobLocation4;  ?>">
									<option value="Mumbai"> Mumbai </option>
									<option value="Delhi"> Delhi</option>
                                                                        <option value="Kolkata"> Kolkata </option>
									 <option value="Pune"> Pune</option>
									  <option value="Bhopal"> Bhopal </option>
								
                            </select>
            </td>
			<td>
                            <select name="Designation4" required="required" value="<?Php echo $Designation4; ?>">
									<option value="JavaDeveloper"> Java Developer </option>
									<option value="FrontEndDeveloper"> FrontEnd Developer </option>
                                                                        <option value="BackEndDeveloper"> BackEnd Developer </option>
									 <option value="PhythonDeveloper"> Phython Developer </option>
									  <option value="SoftwareDeveloper"> Software Developer </option>
								
                            </select>
            </td>
                       
		</tr>
                <tr>
		<td colspan="7" align="center"><br><br>
		  <font color="black"><input type="submit" class="btn btn-primary" value="Update">
		</td>
	</tr>
		
        </table>				
	</form>
 <?php include 'footer.php';?>

