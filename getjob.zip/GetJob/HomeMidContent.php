
<div class="container">
    <div class="col-md-6">
  <div class="panel panel-default">
    <div class="panel-heading">Latest News</div>
    <div class="panel-body">
        <ul>
            <li>This is news1</li>
            <li>This is news1</li>
            <li>This is news1</li>
            <li>This is news1</li>
            <li>This is news1</li>
        </ul>
    </div>
  </div>
    </div>
    <div class="col-md-6">
  <div class="panel panel-default">
    <div class="panel-heading">Notifications</div>
    <div class="panel-body">
        <ul>
            <li>This is news1</li>
            <li>This is news1</li>
            <li>This is news1</li>
            <li>This is news1</li>
            <li>This is news1</li>
        </ul>
   
    </ul>
    </div>
  </div>
</div>
</div>
<center><h1>Our Team</h1></center>
<div class="container">
    <div class="col-md-1">
    </div>
    <div class="col-md-10">
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'CEO')" id="defaultOpen">CEO</button>
  <button class="tablinks" onclick="openCity(event, 'Manager')">Manager</button>
  <button class="tablinks" onclick="openCity(event, 'member1')">Developer</button>
  <button class="tablinks" onclick="openCity(event, 'member2')">Developer</button>
  <button class="tablinks" onclick="openCity(event, 'member3')">Developer</button>
  <button class="tablinks" onclick="openCity(event, 'member4')">Developer</button>
  <button class="tablinks" onclick="openCity(event, 'member5')">Developer</button>
  <button class="tablinks" onclick="openCity(event, 'member6')">Developer</button>
</div>

<div id="CEO" class="tabcontent">
    <center>
    <img class="vinit" src="https://clarktalkblogdotcom.files.wordpress.com/2016/01/53-_top_timing_strategies_for_corporate_relocation.jpg?w=1024&h=512" alt="Los Angeles" width="100">
  <p><b>Founder of Company Abc</b></p>
  <p style="width: 20%">
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abcoulomb
      This is abcoulomb
      
              
  </p>
  <b> -vinit Mapari</b>
    </center>
</div>

<div id="Manager" class="tabcontent">
 <center>
    <img class="vinit" src="https://clarktalkblogdotcom.files.wordpress.com/2016/01/53-_top_timing_strategies_for_corporate_relocation.jpg?w=1024&h=512" alt="Los Angeles" width="100">
  <p><b>Founder of Company Abc</b></p>
  <p style="width: 20%">
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abcoulomb
      This is abcoulomb
      
              
  </p>
  <b> -ABC</b>
    </center>
</div>

<div id="member1" class="tabcontent">
<center>
    <img class="vinit" src="https://clarktalkblogdotcom.files.wordpress.com/2016/01/53-_top_timing_strategies_for_corporate_relocation.jpg?w=1024&h=512" alt="Los Angeles" width="100">
  <p><b>Founder of Company Abc</b></p>
  <p style="width: 20%">
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abcoulomb
      This is abcoulomb
      
              
  </p>
  <b> -XYZ</b>
    </center>
</div>
<div id="member2" class="tabcontent">
  <center>
    <img class="vinit" src="https://clarktalkblogdotcom.files.wordpress.com/2016/01/53-_top_timing_strategies_for_corporate_relocation.jpg?w=1024&h=512" alt="Los Angeles" width="100">
  <p><b>Founder of Company Abc</b></p>
  <p style="width: 20%">
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abcoulomb
      This is abcoulomb
      
              
  </p>
  <b> -ABC</b>
    </center>
</div>
<div id="member3" class="tabcontent">
  <center>
    <img class="vinit" src="https://clarktalkblogdotcom.files.wordpress.com/2016/01/53-_top_timing_strategies_for_corporate_relocation.jpg?w=1024&h=512" alt="Los Angeles" width="100">
  <p><b>Founder of Company Abc</b></p>
  <p style="width: 20%">
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abcoulomb
      This is abcoulomb
      
              
  </p>
  <b> -XYZ</b>
    </center>
</div>
<div id="member4" class="tabcontent">
 <center>
    <img class="vinit" src="https://clarktalkblogdotcom.files.wordpress.com/2016/01/53-_top_timing_strategies_for_corporate_relocation.jpg?w=1024&h=512" alt="Los Angeles" width="100">
  <p><b>Founder of Company Abc</b></p>
  <p style="width: 20%">
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abcoulomb
      This is abcoulomb
      
              
  </p>
  <b> -XYZ</b>
    </center>
</div>
<div id="member5" class="tabcontent">
  <center>
    <img class="vinit" src="https://clarktalkblogdotcom.files.wordpress.com/2016/01/53-_top_timing_strategies_for_corporate_relocation.jpg?w=1024&h=512" alt="Los Angeles" width="100">
  <p><b>Founder of Company Abc</b></p>
  <p style="width: 20%">
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abcoulomb
      This is abcoulomb
      
              
  </p>
  <b> -ABC</b>
    </center>
</div>
<div id="member6" class="tabcontent">
  <center>
    <img class="vinit" src="https://clarktalkblogdotcom.files.wordpress.com/2016/01/53-_top_timing_strategies_for_corporate_relocation.jpg?w=1024&h=512" alt="Los Angeles" width="100">
  <p><b>Founder of Company Abc</b></p>
  <p style="width: 20%">
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abc
      This is abcoulomb
      This is abcoulomb
      
              
  </p>
  <b> -vinit Mapari</b>
    </center>
</div>
    </div>
    <div class="col-md-1">
        
    </div>
</div>
<script>
function openCity(evt, cityName) {
    var i, tabcontent, tablinks;
    tabcontent = document.getElementsByClassName("tabcontent");
    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }
    tablinks = document.getElementsByClassName("tablinks");
    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className = tablinks[i].className.replace(" active", "");
    }
    document.getElementById(cityName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
