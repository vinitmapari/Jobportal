<footer id="footer" class="text-center">
    
    <nav class="navbar navbar-inverse">
  <div class="container-fluid">
      
          
    <ul class="nav navbar-nav navbar-left">
        
      <li class="active">
          <script>
              function myMap() {
              var mapProp = {
    center:new google.maps.LatLng(16.0560968,73.474859),
    zoom:10,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  var map=new google.maps.Map(document.getElementById("googleMap"), mapProp);
}
google.maps.event.addDomListener(window, 'load', initialize);
/*function myMap() {
var mapOptions = {
    center: new google.maps.LatLng(16.05,73.47),
    zoom: 10,
    mapTypeId: google.maps.MapTypeId.HYBRID
};
var map = new google.maps.Map(document.getElementById("googleMap"), mapOptions);
}*/
</script>
<iframe src="https://goo.gl/BqqExg" width="360" height="300" frameborder="0" style="border:0" allowfullscreen>
          <div class="center" align="left" id="googleMap" style="width:300px;height:200px;"></div></iframe>
       <a href="https://www.google.co.in/maps/@16.0560968,73.4748595,21z?hl=en">Find Us With Google Maps &raquo;</a>
      </li>
      
      <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
     
     <li>
             <address><br><br><font color="white">
        Address: Ground Floor, 
        Kiran Mangal Society,<br>
        Bhandar Lane, Off L J Road,
        Behind Subway,<br>
        Mahim, Mumbai 400016<br>
        (10-minute walk from <br> 
        Matunga Road Railway Station)<br>
        <i class="fa fa-envelope-o pright-10"></i> Website: www.vidyarjanconsulting.com<br>
        <i class="fa fa-phone pright-10"></i>Tel: 9892874030<br>
        <i class="fa fa-envelope-o pright-10"></i> <a href="#"><h4>Email: admin@vidyarjanconsulting.com</h4></a>
        
        </address> </font>
     </li>
    
     <li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
     
     
     <li>
         <br><br><font color="white">
		<div>Follow Us on Social Media</div><br>
		<div class="socialMedia">
		<label class="facebookDiv"><a target="_blank" href="https://www.facebook.com/anuragnarkhede/">
		<img src="https://www.baapoffers.com/images/facebook.png" alt="Facebook" style="width: 35px;" />
                    </a></label>&nbsp;&nbsp;&nbsp;
		<label class="twitterDiv"><a target="_blank" href="https://twitter.com/anuragnarkhede1">
		<img src="https://www.baapoffers.com/images/twitter.png" alt="twitter" style="width: 35px;"/>
		</a></label>&nbsp;&nbsp;&nbsp;
		<label class="googleDiv"><a target="_blank" href="https://plus.google.com/u/0/117515715085714607552">
		<img src="https://www.baapoffers.com/images/google-plus.png" alt="Google" style="width: 35px;"/>
		</a></label>&nbsp;&nbsp;&nbsp;
		<label class="instaDiv"><a target="_blank"  href="https://www.instagram.com/anuragnarkhede/">
		<img src="https://www.baapoffers.com/images/instagram.png" alt="instagram" style="width: 35px;"/>
		</a></label>
		</div></font>
     </li>
    </ul>
</nav>
<p>Copyright 2017 &COPY; jobwebsite</p>
</footer>
</body>
</html>
